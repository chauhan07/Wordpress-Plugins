<?php

/*
 * this class should be used to stores properties and methods shared by the
 * admin and public side of wordpress
 */

class dalt_Shared
{

    //regex
    public $regex_capability = '/^\s*[A-Za-z0-9_]+\s*$/';
    public $list_of_comma_separated_numbers = '/^(\s*(\d+\s*,\s*)+\d+\s*|\s*\d+\s*)$/';
    public $url_regex = '/^https?:\/\/.+$/';
    public $hex_rgb_regex = '/^#(?:[0-9a-fA-F]{3}){1,2}$/';
    public $font_family_regex = '/^([A-Za-z0-9-\'", ]*)$/';
    public $digits_regex = '/^\s*\d+\s*$/';

    protected static $instance = null;

    private $data = array();

    private function __construct()
    {

        //Set plugin textdomain
        load_plugin_textdomain('dalt', false, 'league-table/lang/');

        $this->data['slug'] = 'dalt';
        $this->data['ver'] = '2.09';
        $this->data['dir'] = substr(plugin_dir_path(__FILE__), 0, -7);
        $this->data['url'] = substr(plugin_dir_url(__FILE__), 0, -7);

    }

    public static function get_instance()
    {

        if (null == self::$instance) {
            self::$instance = new self;
        }

        return self::$instance;

    }

    //retrieve data
    public function get($index)
    {
        return $this->data[$index];
    }

    /*
     * Create a record of the data table filled with the provided data
     *
     * @param $table_id The id of the table
     * @param $row_index The index of the data structure row
     * @param $row_data_json The data of a single data structure row in the json format
     */
    public function data_insert_record($table_id, $row_index, $row_data_json)
    {

        //save in the db table
        global $wpdb;
        $table_name = $wpdb->prefix . $this->get('slug') . "_data";
        $safe_sql = $wpdb->prepare("INSERT INTO $table_name SET
            table_id = %d,
            row_index = %d,
            content = %s",
            $table_id,
            $row_index,
            $row_data_json
        );

        $query_result = $wpdb->query($safe_sql);

    }

    /*
     * Applies stripslashes to all the properties of an object
     *
     * @param Object
     * @return Object
     */
    public function object_stripslashes($obj)
    {

        $property_a = get_object_vars($obj);

        foreach ($property_a as $key => $value) {

            $obj->{$key} = stripslashes($value);

        }

        return $obj;

    }

    /*
     * If the data of the cell exists updates the data based on the provided $cell_info Object.
     * If the data of the cell doesn't exist creates a new record based on the provided $cell_info Object.
     *
     * @param $cell_info
     * @return The result of the query
     */
    public function save_cell($cell_info)
    {

        //Verifies if the cell already exists
        global $wpdb;
        $table_name = $wpdb->prefix . $this->get('slug') . "_cell";
        $safe_sql = $wpdb->prepare("SELECT COUNT(*) FROM $table_name WHERE
        table_id = %d AND row_index = %d AND column_index = %d",
            $cell_info->table_id,
            $cell_info->row_index,
            $cell_info->column_index);
        $cell_count = $wpdb->get_var($safe_sql);

        if ($cell_count > 0) {

            //update the cell data properties
            global $wpdb;
            $table_name = $wpdb->prefix . $this->get('slug') . "_cell";
            $safe_sql = $wpdb->prepare("UPDATE $table_name SET
            html_content = %s,
            text_color = %s,
            background_color = %s,
            font_weight = %s,
            font_style = %s,
            link = %s,
            link_color = %s,
            open_link_new_tab = %d,
            image_left = %s,
            image_left_link = %s,
            image_left_open_link_new_tab = %d,
            image_right = %s,
            image_right_link = %s,
            image_right_open_link_new_tab = %d,
            alignment = %s,
            formula = %s,
            formula_data = %s,
            row_slots = %d,
            column_slots = %d
            WHERE table_id = %d AND row_index = %d AND column_index = %d",
                $cell_info->html_content,
                $cell_info->text_color,
                $cell_info->background_color,
                $cell_info->font_weight,
                $cell_info->font_style,
                $cell_info->link,
                $cell_info->link_color,
                $cell_info->open_link_new_tab,
                $cell_info->image_left,
                $cell_info->image_left_link,
                $cell_info->image_left_open_link_new_tab,
                $cell_info->image_right,
                $cell_info->image_right_link,
                $cell_info->image_right_open_link_new_tab,
                $cell_info->alignment,
                $cell_info->formula,
                $cell_info->formula_data,
	            $cell_info->row_slots,
	            $cell_info->column_slots,
                $cell_info->table_id,
                $cell_info->row_index,
                $cell_info->column_index);
            $result = $wpdb->query($safe_sql);

        } else {

            //if the properties of the cell don't exist create the cell data properties
            global $wpdb;
            $table_name = $wpdb->prefix . $this->get('slug') . "_cell";
            $safe_sql = $wpdb->prepare("INSERT INTO $table_name SET
            html_content = %s,
            text_color = %s,
            background_color = %s,
            font_weight = %s,
            font_style = %s,
            link = %s,
            link_color = %s,
            open_link_new_tab = %d,
            image_left = %s,
            image_left_link = %s,
            image_left_open_link_new_tab = %d,
            image_right = %s,
            image_right_link = %s,
            image_right_open_link_new_tab = %d,
            alignment = %s,
            formula = %s,
            formula_data = %s,
            row_slots = %d,
            column_slots = %d,
            table_id = %d,
            row_index = %d,
            column_index = %d",
                $cell_info->html_content,
                $cell_info->text_color,
                $cell_info->background_color,
                $cell_info->font_weight,
                $cell_info->font_style,
                $cell_info->link,
                $cell_info->link_color,
                $cell_info->open_link_new_tab,
                $cell_info->image_left,
                $cell_info->image_left_link,
                $cell_info->image_left_open_link_new_tab,
                $cell_info->image_right,
                $cell_info->image_right_link,
                $cell_info->image_right_open_link_new_tab,
                $cell_info->alignment,
                $cell_info->formula,
                $cell_info->formula_data,
                $cell_info->row_slots,
                $cell_info->column_slots,
                $cell_info->table_id,
                $cell_info->row_index,
                $cell_info->column_index);
            $result = $wpdb->query($safe_sql);

        }

        return $result;

    }

    /*
     * Returns the total number of non-temporary tables
     *
     * @return int The number of non-temporary tables
     */
    public function get_number_of_tables()
    {

        global $wpdb;
        $table_name = $wpdb->prefix . $this->get('slug') . "_table";
        $number_of_tables = $wpdb->get_var("SELECT COUNT(*) FROM $table_name WHERE temporary = 0");

        return $number_of_tables;

    }

    /*
     * Applies wp_kses() with the allowed tags and parameters defined in the plugin options.
     *
     * @param String The HTML that should be filtered
     * @return String The HTML filter by wp_kses() (if "Apply kses" is enabled) or the unfilter HTML (if "Apply kses" is
     * not enabled).
     */
    public function apply_custom_kses($string)
    {

        if (get_option($this->get('slug') . '_apply_kses') == 1) {

            /*
             * The final $allowed_html should have this format, for more info see
             * https://codex.wordpress.org/Function_Reference/wp_kses
             *
             * $allowed_html = array(
             *     'a' => array(
             *         'href' => array(),
             *         'title' => array()
             *     ),
             *     'br' => array(),
             *     'em' => array(),
             *     'strong' => array(),
             * );
             */

            $allowed_html = array();
            $kses_allowed_html_tags = get_option($this->get('slug') . '_kses_allowed_html_tags');
            $list_of_tags_a = explode(',', $kses_allowed_html_tags);

            foreach ($list_of_tags_a as $tag_with_attributes) {

                //store the allowed attributes of this tag in an array with a regex
                preg_match_all('/\[([a-z-]*)\]/', $tag_with_attributes, $matches);
                $allowed_attributes_a = $matches[1];

                //remove the allowed attributes from the string and store the allowed tag in a variable with a regex
                $allowed_tag = trim(preg_replace('(\[[a-z-]*\])', '', $tag_with_attributes));

                //create an array with the proper form required by the wp_kses() function
                $attributes = array();
                foreach ($allowed_attributes_a as $allowed_attribute) {
                    $attributes[$allowed_attribute] = array();
                }

                //add the tag only if it's validated with a regex
                if (preg_match('/^[a-z]*$/', $allowed_tag)) {
                    $allowed_html[$allowed_tag] = $attributes;
                }

            }

            /*
             * Set the allowed protocols.
             *
             * The final $allowed_protocols should have this format, for more info see
             * https://codex.wordpress.org/Function_Reference/wp_kses
             *
             * $allowed_protocols = array('http', 'https', 'ftp');
             */

            //get the value in the option
            $allowed_protocols = get_option($this->get('slug') . '_kses_allowed_protocols');

            //remove all the spaces
            $allowed_protocols = str_replace(' ', '', $allowed_protocols);

            //convert to an array
            $allowed_protocols = explode(',', $allowed_protocols);

            //Use the custom $allowed_html and $allowed_protocols to apply wp_kses()
            return wp_kses($string, $allowed_html, $allowed_protocols);

        } else {

            return $string;

        }

    }

    /*
     * Get the number of columns available in the table.
     *
     * @param int The id of the table
     * @param bool A boolean value which indicated if the position column, generated in the front-end via JavaScript,
     * should be considered in the calculation of the number of columns.
     * @return int The number of columns available in the table.
     */
    function get_number_of_columns($table_id, $consider_position_column){

	    global $wpdb;
	    $number_of_columns = 0;

	    /*
	     * Sum the number of columns found in the serialized field "content" of the data table to $number_of_columns.
		 */
	    $table_name = $wpdb->prefix . $this->get('slug') . "_data";
	    $safe_sql = $wpdb->prepare("SELECT * FROM $table_name WHERE table_id = %d ORDER BY row_index DESC", $table_id);
	    $data_a = $wpdb->get_results($safe_sql);

	    $row_data = json_decode($data_a[0]->content, true);
	    $number_of_columns = $number_of_columns + count($row_data);

	    /*
	     * Add 1 to $number_of_columns if:
	     *
	     * - The position column should be considered
	     * - If the position column is enabled in this table
	     */
	    $table_name = $wpdb->prefix . $this->get('slug') . "_table";
	    $safe_sql = $wpdb->prepare("SELECT * FROM $table_name WHERE id = %d", $table_id);
	    $table_obj = $wpdb->get_row($safe_sql);

	    if(intval($consider_position_column, 10) ===1 and intval($table_obj->show_position, 10) === 1){
		    $number_of_columns = $number_of_columns + 1;
	    }

		return $number_of_columns;

    }

	/**
	 * Returns the value of the "rows" field of the "table" db table
	 *
	 * @param $table_id The table id
	 * @return Int the value of the "rows" field
	 */
	function get_rows_field($table_id){

		global $wpdb;
		$table_name = $wpdb->prefix . $this->get('slug') . "_table";
		$safe_sql = $wpdb->prepare("SELECT `rows` FROM $table_name WHERE id = %d", $table_id);
		$table_obj = $wpdb->get_row($safe_sql);

		return intval($table_obj->rows, 10);

	}

	/**
	 * Returns the value of the "columns" field of the "table" db table
	 *
	 * @param $table_id The table id
	 * @return Int the value of the "columns" field
	 */
    function get_columns_field($table_id){

    	global $wpdb;
	    $table_name = $wpdb->prefix . $this->get('slug') . "_table";
	    $safe_sql = $wpdb->prepare("SELECT columns FROM $table_name WHERE id = %d", $table_id);
	    $table_obj = $wpdb->get_row($safe_sql);

	    return intval($table_obj->columns, 10);

    }

	/*
	 * Empty objects are replaced with empty strings.
	 * This prevent to generate notices with the methods of the wpdb class.
	 *
	 * @param $data An array which includes empty objects that should be converted to empty strings
	 * @return string An array where the empty objects have been replaced with empty strings
	 */
	public function replace_empty_objects_with_empty_strings($data){

		foreach($data as $key => $value){
			if(gettype($value) === 'object'){

				/**
				 * Verify if the $value object is empty by typecasting it into an array. In case it's empty replace its
				 * value with an empty string.
				 *
				 * Ref: https://stackoverflow.com/questions/9412126/how-to-check-that-an-object-is-empty-in-php
				 */
				$arr = (array)$value;
				if (empty($arr)) {
					$data[$key] = '';
				}

			}
		}

		return $data;

	}

	/**
	 * Check the AJAX referer.
	 */
	public function check_ajax_referer(){

		//check the referer
		if (!check_ajax_referer('dalt', 'security', false)) {
			echo "Invalid AJAX Request";
			die();
		}

	}

	/**
	 * Check the tables menu capability.
	 */
	public function check_tables_menu_capability(){

		//check the capability
		if (!current_user_can(get_option($this->get('slug') . "_tables_menu_capability"))) {
			echo 'Invalid Capability';
			die();
		}

	}

	/**
	 * Set the maximum execution time defined in the "Max Execution Time" option.
	 */
	public function set_max_execution_time(){

		ini_set('max_execution_time', intval(get_option($this->get('slug') . "_max_execution_time"), 10));

	}

	/**
	 * Set the memory limit in megabytes defined in the "Memory limit" option.
	 */
	public function set_memory_limit(){

		ini_set('memory_limit', intval(get_option($this->get('slug') . "_memory_limit"), 10) . 'M');

	}

}