/**
 * All blocks related JavaScript files should be imported here.
 * You can create a new block folder in this directory and include code for that
 * block here as well.
 *
 * All blocks should be included here since this is the file that Webpack is
 * compiling as the entry point.
 */

import './select-table/index.js';
