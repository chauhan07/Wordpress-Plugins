/*
 * initialization of the wp color picker
 */
jQuery(document).ready(function($){
    
    $('.wp-color-picker').wpColorPicker();
    
});