jQuery(document).ready(function($) {

    //initialize chosen on all the select elements

    var chosen_elements = [];

    //General
    chosen_elements.push("#dalt-limit-shortcode-parsing");
    chosen_elements.push("#dalt-verify-single-shortcode");
    chosen_elements.push("#dalt-widget-text-shortcode");
    chosen_elements.push("#dalt-apply-kses");
    
    //Cell Properties
    chosen_elements.push("#dalt-enable-text-color-cell-property");
    chosen_elements.push("#dalt-enable-background-color-cell-property");
    chosen_elements.push("#dalt-enable-alignment-cell-property");
    chosen_elements.push("#dalt-enable-font-weight-cell-property");
    chosen_elements.push("#dalt-enable-font-style-cell-property");
    chosen_elements.push("#dalt-enable-link-cell-property");
    chosen_elements.push("#dalt-enable-link-color-cell-property");
    chosen_elements.push("#dalt-enable-open-link-new-tab-cell-property");
    chosen_elements.push("#dalt-enable-image-left-cell-property");
    chosen_elements.push("#dalt-enable-image-left-link-cell-property");
    chosen_elements.push("#dalt-enable-image-left-open-link-new-tab-cell-property");
    chosen_elements.push("#dalt-enable-image-right-cell-property");
    chosen_elements.push("#dalt-enable-image-right-link-cell-property");
    chosen_elements.push("#dalt-enable-image-right-open-link-new-tab-cell-property");
    chosen_elements.push("#dalt-enable-formula-cell-property", "1");
    chosen_elements.push("#dalt-enable-formula-data-cell-property");
    chosen_elements.push("#dalt-enable-html-content-cell-property");
    chosen_elements.push("#dalt-enable-row-slots-cell-property");
    chosen_elements.push("#dalt-enable-column-slots-cell-property");

    jQuery(chosen_elements.join(',')).chosen();

});