(function() {
	"use strict";

	document.addEventListener('appReady.EappsInstagramFeed', function() {
		var widgets = document.querySelectorAll('[data-elfsight-instagram-feed-options]');

		Array.prototype.slice.call(widgets).forEach(function(widget) {
			var version = widget.getAttribute('data-elfsight-instagram-feed-version');
			var options = widget.getAttribute('data-elfsight-instagram-feed-options');
			var data = JSON.parse(decodeURIComponent(options));

			window.eappsInstagramFeed(widget, data);

			widget.removeAttribute('data-elfsight-instagram-feed-options');
			widget.removeAttribute('data-elfsight-instagram-feed-version');

			widget.data = {
				options: data,
				version: version
			};
		});
	});

	//= ../app/app/dist/instagram-feed.js
})();