<?php
/**
 * Plugin Name: WooCommerce MYOB Integration
 * Plugin URI: https://woocommerce.com/products/myob_integration/
 * Description: Create customer In MYOB and create invoice when order is placed.
 * Version: 2.8
 * Author: WooCommerce
 * Author URI: https://woocommerce.com
 * WC tested up to: 5.8
 * WC requires at least: 2.6
 *
 * Woo: 4830850:d27ed26e37c2d588dfa5fa5723d563fa
 *
 * Copyright: 2009-2018 WooCommerce.
 * License: GNU General Public License v3.0
 * License URI: http://www.gnu.org/licenses/gpl-3.0.html
 *
 * @package WC_MYOB_Integration
 */

//define ( 'OPMC_TRACE', '1' );

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

class Opmc_Myob_Exception extends Exception {} 


define( 'WC_MYOB_INTEGRATION_INIT_VERSION', '1.0.0' );
define( 'WC_MYOB_INTEGRATION_PLUGINURL', plugin_dir_url( __FILE__ ) );
define( 'WC_MYOB_INTEGRATION_PLUGINDIR', plugin_dir_path( __FILE__ ) );
define( 'HOME_URL', home_url('/') );
define( 'TOKEN_URI', 'https://secure.myob.com/oauth2/v1/authorize' );

define( 'WC_MYOB_API_CLIENT_ID', '545dj2wk4r8gde2xs39mg366' );

define( 'WC_MYOB_API_REDIRECT_URL', 'https://myob-auth.nicer8.com/myob-authentication.html' );
/**
 * Required functions.
 */
if ( ! function_exists( 'woothemes_queue_update' ) ) {
	require_once( 'woo-includes/woo-functions.php' );
}

require_once( 'includes/opmc/class-opmc-logger.php' );
require_once( 'includes/class-opmc-myob-connector.php' );
require_once( 'includes/myob-helper-functions.php' );


if (version_compare(phpversion(), '7.1', '>=')) {
	ini_set( 'serialize_precision', -1 );
}

/**
 * Plugin updates
 */
woothemes_queue_update(plugin_basename(__FILE__), 'd27ed26e37c2d588dfa5fa5723d563fa', '4830850');


//$MYOB_integrations = get_option('woocommerce_MYOB_integrations_settings');


/* handle initial activation */
register_activation_hook( __FILE__, 'opmc_install_myob_integration_plugin' );

function opmc_install_myob_integration_plugin() {
	if (!in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {
		echo '<h4>' . esc_html(__('WooCommerce plugin is missing. This plugin requires WooCommerce.', 'ap')) . '</h4>';
		/*Adding @ before will prevent XDebug output*/
		@trigger_error(esc_html(__('Please install WooCommerce before activating.', 'ap')), E_USER_ERROR);
	}
}


/**
*  Main integration class
*/
if ( ! class_exists( 'WC_MYOB_Integration' ) ) :
	class WC_MYOB_Integration {

		private $connector = null;
		protected static $instance = null;


		/**
		* Implement Singleton
		*/
		public static function get_instance() {
			// If the single instance hasn't been set, set it now.
			if ( null == self::$instance ) {
				self::$instance = new self();
			}

			return self::$instance;
		}



		/**
		* Construct the plugin.
		*/
		public function __construct() {
			$connector = new Opmc_Myob_Connector();

			Opmc_Logger::trace('Constructing main class');
			//add_action( 'plugins_loaded', array( $this, 'init' ) );
			$this->init();
			// called when a new order is created
			//add_action( 'woocommerce_checkout_order_processed', array( $connector,'place_order'), 1, 1  );

			// add_action( 'woocommerce_payment_complete', array( $connector,'place_order'), 1, 1  );
			// add_action( 'woocommerce_subscription_renewal_payment_complete', array( $connector,'place_order'), 1, 1  );

			add_action( 'woocommerce_order_status_changed', array($connector, 'order_from_status_transition_hook'), 1, 3);

			// add_action( 'woocommerce_payment_complete', array( $connector,'order_from_payment_complete_hook'), 1, 1  );
			add_action( 'woocommerce_subscription_renewal_payment_complete', array( $connector,'order_from_payment_complete_hook'), 1, 1  );
			
			// Actions for adding a new order action for resyncing woocommerce orders with MYOB.
			add_action( 'woocommerce_order_actions', array( $this, 'add_order_meta_box_actions' ));
			add_action( 'woocommerce_order_action_resync_order_to_myob', array($connector, 'resync_order_to_myob'), 1, 1);

			// cron schedule setup for reauthorization to MYOB API
			add_filter('cron_schedules', array($this, 'add_cron_interval') );
			// create a hook to init our cron settings
			//add_action('WC_MYOB_wp', array($this,'init_cron_schedule') );
			$this->init_cron_schedule();

			//cron job perform action
			add_action( 'WC_MYOB_access_cron', array($connector, 'refresh_token' ) );
			//define custom time for cron job

			// cron to sync inventory levels daily
			add_action( 'WC_MYOB_sync_cron', array($connector, 'sync_inventory_data' ) );

			// cron to run keep alive transient

			add_action( 'WC_MYOB_keep_alive_transient_cron', array($connector, 'MYOB_keep_alive_transient' ) );


			//deactivation hook
			//add_action( 'deactivated_plugin', array($this,'MYOB_plugin_deactivation') );

			add_action( 'add_option_woocommerce_myob_integrations_settings', array($this,'add_myob_cron'), 10, 2);
			add_action( 'update_option_woocommerce_myob_integrations_settings', array($this,'update_myob_cron'), 10, 2);
			add_action( 'myob_process_product_sync', array($this, 'sync_product_from_myob_to_woo'));
			add_action( 'admin_notices', array( $this, 'admin_notices' ) );

			 // Scripts
			add_action( 'admin_enqueue_scripts', array( $this, 'settings_scripts' ) );
			
			add_action( 'wp_ajax_MYOB_sync_product_ajax', 'MYOB_sync_product_ajax' );
			add_action( 'wp_ajax_MYOB_import_product_to_myob', 'MYOB_import_product_to_myob' ); 
			add_action( 'wp_ajax_MYOB_reload_accounts_list_ajax', 'MYOB_reload_accounts_list_ajax' );

			add_action('woocommerce_order_status_changed', array($connector,'change_order_status'), 10, 4 );
			// add_action( 'save_post', array( $connector,'do_insert_product_in_myob' ), 10, 2); PLUGINS-635

			//Run keep alive transient available every 10 minutes
			add_action('admin_init', array($connector,'MYOB_keep_alive_transient'));
			
			//Job code scripts.
			add_action( 'add_meta_boxes', array( $this, 'myob_meta_box' ) );
			add_action( 'save_post', array($this,'save_myob_meta_box'), 10, 2);	

			register_deactivation_hook( __FILE__, array( $this, 'MYOB_plugin_deactivation' ) );
		}


		/**
		Enqueue required JavaScript
		*/
		public function settings_scripts() {
			wp_enqueue_script( 'MYOB_script', plugin_dir_url( __FILE__ ) . 'assets/js/myob_scripts.js', null , '1.2' );
			add_action( 'init', 'my_script_enqueuer' );
			wp_localize_script( 'my_voter_script', 'myAjax', array( 'ajaxurl' => admin_url( 'admin-ajax.php' )));
			wp_enqueue_script( 'my_voter_script' );
		}

		/**
		* Initialize the plugin.
		*/
		public function init() {

			// Checks if WooCommerce is installed.
			if ( class_exists( 'WC_Integration' ) ) {
				// Include our integration class.
				include_once 'includes/class-wc-myob-admin-settings.php';
				// Register the integration.
				add_filter( 'woocommerce_integrations', array( $this, 'add_integration' ) );
			}
		}

		/**
		 * Add a new integration to WooCommerce.
		 */
		public function add_integration( $integrations ) {
			$integrations[] = 'WC_MYOB_Integrations_Settings';
			return $integrations;
		}


		/**
		 * Adds a new action to the list of WooCommerce order actions, before returning the list.
		 */ 
		public function add_order_meta_box_actions( $actions ) {
			$actions['resync_order_to_myob'] = __( 'Resync order to MYOB' );
			return $actions;
		}


		/*
		* cron_schedules
		* check and execute cron job
		*/
		public function init_cron_schedule() {
					$woocommerce_MYOB_integrations_settings =  get_option('woocommerce_MYOB_integrations_settings'); 
					$WC_MYOB_company_file_id = isset($woocommerce_MYOB_integrations_settings['WC_MYOB_company_file_id']) ? $woocommerce_MYOB_integrations_settings['WC_MYOB_company_file_id'] : '';
					$WC_MYOB_company_file_username = isset($woocommerce_MYOB_integrations_settings['WC_MYOB_company_file_username']) ? $woocommerce_MYOB_integrations_settings['WC_MYOB_company_file_username'] : '';
			if (!empty($WC_MYOB_company_file_id) && !empty($WC_MYOB_company_file_username)) {
				///wp_schedule_event( int $timestamp, string $recurrence, string $hook, array $args = array() )
				if ( !wp_next_scheduled( 'WC_MYOB_access_cron' ) ) {
						//wp_schedule_event(time(), 'WC_MYOB_further_attempt', 'WC_MYOB_access_cron');
						wp_schedule_event(time(), 'WC_MYOB_cron_interval', 'WC_MYOB_access_cron' );
						Opmc_Logger::debug('Added cron job for MYOB integration');
				}

				if ( !wp_next_scheduled( 'WC_MYOB_sync_cron' ) ) {
						wp_schedule_event( time(), 'WC_MYOB_cron_interval_sync', 'WC_MYOB_sync_cron' ); 
				}

				// Schedule Keep Alive transient twice daily
				if ( !wp_next_scheduled( 'WC_MYOB_keep_alive_transient_cron' ) ) {
					  wp_schedule_event( time(), 'twicedaily', 'WC_MYOB_keep_alive_transient_cron' );
				}
			}
		}

		/*
		* cron_schedules
		* set interval for function to execute as cron job
		*/
		public function add_cron_interval( $schedules ) {

			$schedules['WC_MYOB_cron_interval'] = array(
				'interval'  =>  600,
				'display'   => __( 'MYOB 10 Minute Schedule', 'textdomain' )
			);
						$woocommerce_MYOB_integrations_settings =  get_option('woocommerce_MYOB_integrations_settings'); 
						$WC_MYOB_sync_period = isset($woocommerce_MYOB_integrations_settings['WC_MYOB_sync_period']) ? $woocommerce_MYOB_integrations_settings['WC_MYOB_sync_period'] : '';
			if (empty($WC_MYOB_sync_period)) {
				$WC_MYOB_sync_period = 1;
			}
						$intervalPeriod = 86400 * $WC_MYOB_sync_period;
						$schedules['WC_MYOB_cron_interval_sync'] = array(
				'interval'  =>   $intervalPeriod, 
				'display'   => __( 'MYOB ' . $WC_MYOB_sync_period . ' Days Schedule', 'textdomain' )
						);

						return $schedules;
		}

		/*MYOB deactivation*/
		public function MYOB_plugin_deactivation() {
			// remove crons
			$timestamp = wp_next_scheduled( 'WC_MYOB_acces_cron' );
			//$wp_unschedule_event ( $timestamp, 'WC_MYOB_access_cron');

			// delete settings
			delete_option( 'woocommerce_MYOB_integrations_settings' );

			delete_option( 'WC_MYOB_client_id' );
			delete_option( 'WC_MYOB_secret' );
			delete_option( 'WC_MYOB_code' );
			delete_option( 'MYOB_access_token' );
			delete_option( 'MYOB_access_refresh_token' );
			delete_option( 'MYOB_access_token_type' );
			delete_option( 'MYOB_access_token_scope' );

			delete_option( 'WC_MYOB_asset_accounts_list' );
			delete_option( 'WC_MYOB_cogs_accounts_list' );
			delete_option( 'WC_MYOB_company_file_list' );
			delete_option( 'WC_MYOB_expense_accounts_list' );
			delete_option( 'WC_MYOB_income_accounts_list' );
			delete_option( 'WC_MYOB_tax_codes_list' );
			delete_option( 'WC_MYOB_refresh_token_timestamp' );

			// delete_option( 'myob_customer_count' );
			// delete_option( 'myob_customer_pull_next_url' );
			// delete_option( 'myob_customer_synced_count' );
			delete_option( 'myob_product_count' );
			delete_option( 'myob_product_pull_next_url' );
			delete_option( 'myob_product_synced_count' );

			//Clear transients
			delete_transient( 'MYOB_keep_alive_transient' );
			delete_transient( 'MYOB_keep_alive_run' );
			//Clear scheduled events
			wp_clear_scheduled_hook('WC_MYOB_keep_alive_transient_cron');
			wp_clear_scheduled_hook('WC_MYOB_sync_cron');
			wp_clear_scheduled_hook('WC_MYOB_access_cron');
			wp_clear_scheduled_hook('myob_process_product_sync');

		}
		public function myob_meta_box( $post_type ) {
			$post_types = array('product');
			if (in_array($post_type, $post_types)) {
				add_meta_box(
					'wf_child_letters'
					, __( 'MYOB AccountRight', 'myob_integrations' )
					, array( $this, 'myob_meta_box_content' )
					, $post_type
					, 'side'
					, 'high'
				);
			}
		}

		public function myob_meta_box_content() {
			global $post;
			include_once WC_MYOB_INTEGRATION_PLUGINDIR . '/includes/opmc/template-opmc-product-meta-box.php';
		}

		public function save_myob_meta_box( $post_id ) {
			// Check if nonce is set
			if ( ! isset( $_POST['myob_job_nonce'] ) ) {
				return $post_id;
			}

			if ( ! wp_verify_nonce( !empty($_POST['myob_job_nonce']) ? sanitize_text_field( $_POST['myob_job_nonce'] ) : '' , 'save_myob_nonce' ) ) {
				return $post_id;
			}

			// Check that the logged in user has permission to edit this post
			if ( ! current_user_can( 'edit_post' ) ) {
				return $post_id;
			}

			$product_job = !empty($_POST['myob_product_job_code']) ? sanitize_text_field( $_POST['myob_product_job_code'] ) : '';
			update_post_meta( $post_id, '_myob_product_job_code', $product_job );
		}


		/**
		 * Initiates the process for product synchronisation between MYOB and WooCommerce. Called via a hook to the myob_process_product_sync cron job.
		 */ 
		public function sync_product_from_myob_to_woo() {

			Opmc_Logger::debug('Call to sync_product_from_myob_to_woo() in myob-integration');

			$connector = new Opmc_Myob_Connector();
			if ( $connector ) {
				$connector->sync_products_from_myob();
			}
		}


		/**
		 * Schedules the cron job for product synchronisation between MYOB and WooCommerce based on the value of the admin setting.
		 */ 
		public function add_myob_cron( $v, $data ) {

			Opmc_Logger::debug("Call to add_myob_cron() in myob-integration with arguments: $v, $data");
		
			if ( isset($data['WC_OPMC_create_product_to_woo_cron'] ) && ( 'yes' == $data['WC_OPMC_create_product_to_woo_cron'] && !wp_next_scheduled( 'myob_process_product_sync' ) ) ) {
				wp_schedule_event( time(), $data['WC_OPMC_create_product_to_woo_cron_frequency'], 'myob_process_product_sync' );

			}
		}


		/**
		 * Updates the frequency of the cron job for product synchronisation between WooCommerce and MYOB.
		 */
		public function update_myob_cron( $old_values, $new_values) {

			$old_product_cron_frequency = $old_values['WC_OPMC_create_product_to_woo_cron_frequency'];
			$new_product_cron_frequency = $new_values['WC_OPMC_create_product_to_woo_cron_frequency'];

			$config = get_option('woocommerce_MYOB_integrations_settings');

			$setting_value = $config['WC_OPMC_create_product_to_woo_cron'];
			$setting_state = isset($config['WC_OPMC_create_product_to_woo_cron']);

			$schedule_myob_to_woo_product_sync = isset($config['WC_OPMC_create_product_to_woo_cron']) ? $config['WC_OPMC_create_product_to_woo_cron'] : '';

			Opmc_Logger::debug("Call to update_myob_cron() in myob-integration with arguments: $old_product_cron_frequency, $new_product_cron_frequency, $setting_state");
			Opmc_Logger::debug("Value of isset(setting): $setting_state, $schedule_myob_to_woo_product_sync");

			if ('no' != $schedule_myob_to_woo_product_sync) {

				Opmc_Logger::debug('update_myob_cron(): SETTING IS SET, PROCEEDING WITH USUAL CHECK');
				
				if (( !wp_next_scheduled( 'myob_process_product_sync' ) ) || ( $old_values['WC_OPMC_create_product_to_woo_cron_frequency'] != $new_values['WC_OPMC_create_product_to_woo_cron_frequency'] )) {
					wp_clear_scheduled_hook('myob_process_product_sync');
					wp_schedule_event( time(), $new_values['WC_OPMC_create_product_to_woo_cron_frequency'], 'myob_process_product_sync' );
				}
			} else {
				Opmc_Logger::debug('update_myob_cron(): SETTING IS NOT SET, CLEARING myob_process_product_sync HOOK');
				wp_clear_scheduled_hook('myob_process_product_sync');
			}
		}


		/**
		 * Function to display messages to users regarding the status of product synchronisation between WooCommerce and MYOB (both ways).
		 */ 
		public function admin_notices() {

			Opmc_Logger::debug('Call to admin_notices() in myob-integration');

			if (isset($_GET['tab']) && isset($_GET['section']) &&  'integration' == $_GET['tab'] && 'myob_integrations' == $_GET['section']) {

				// Update WooCommerce product catalogue by adding new MYOB products
				if (get_option('myob_product_synced_count') > 0 ) {
					$product_synced = get_option('myob_product_synced_count');
					$product_count = get_option('myob_product_count');
					$product_synced_count = $product_synced > $product_count ? $product_count : $product_synced;
					echo '<div class="notice notice-warning is-dismissible"><p><strong>WooCommerce MYOB AccountRight is syncing products.</strong> ' . esc_html(get_option('myob_product_synced_count')) . ' products have been synced to WooCommerce from MYOB in total. (refresh to update)</p></div>' . "\n";

				}

				// Update MYOB product catalogue by adding new WooCommerce products
				if (get_option('woo_product_synced_to_myob_count') > 0 ) {
					$woo_product_synced = get_option('woo_product_synced_to_myob_count');
					$woo_product_count = get_option('myob_woo_product_count');
					$woo_product_synced_count = $woo_product_synced > $woo_product_count ? $woo_product_count : $woo_product_synced;
					echo '<div class="notice notice-warning is-dismissible"><p><strong>WooCommerce MYOB AccountRight is Syncing products.</strong> ' . esc_html($woo_product_synced_count) . ' products are Synced To MYOB Out of ' . esc_html(get_option('myob_woo_product_count')) . '.</p></div>' . "\n";

				}
			}			
		} 

	}

	add_action( 'plugins_loaded', array( 'WC_MYOB_Integration', 'get_instance' ) );
endif;

//
//  Hooks are below for Ajax functions in Admin panel
//


/**
* Launch the sync process when the store owner clicks the sync button on the admin panel
*/
function MYOB_sync_product_ajax() {
	Opmc_Logger::debug( 'MYOB_sync_product_ajax()' );
	$connector = new Opmc_Myob_Connector();

	if ( $connector ) {
		$connector->sync_inventory_data();
	}
}


/**
 * Create products in MYOB from WooCommerce
 */ 
function MYOB_import_product_to_myob() {
	$connector = new Opmc_Myob_Connector();
	if ( $connector ) {
		$connector->import_product_to_myob();
	}
}

/**
* Reload the accounts list
*/
function MYOB_reload_accounts_list_ajax() {
	Opmc_Logger::debug( 'MYOB_reload_accounts_list_ajax()' );
	$connector = new Opmc_Myob_Connector();

	if ( $connector ) {
		$connector->reload_accounts_list();
	}
}


/**
* For Invoice Layouts
*/
add_action( 'add_meta_boxes', 'so_invoice_type_meta_box' );
function so_invoice_type_meta_box( $post_type) {
	global $post;
	add_meta_box('so_meta_box', 'MYOB Invoice Type', 'invoice_layout_meta_box', $post->post_type, 'side' , 'high');
}

add_action('save_post', 'so_save_metabox');
function so_save_metabox( $post_id) { 
	global $post;
	//Check if nonce is set
	if ( !isset( $_POST['myob_invoice_nonce'] ) ) {
		return $post_id;
	}

	if ( ! wp_verify_nonce( !empty($_POST['myob_invoice_nonce']) ? sanitize_text_field( $_POST['myob_invoice_nonce'] ) : '' , 'save_myob_nonce' ) ) {
		return $post_id;
	}
	if (isset($_POST['myob_invoice_layout_content'])) {
		 //UPDATE: 
		$meta_element_class = sanitize_text_field( wp_unslash($_POST['myob_invoice_layout_content']));
		//END OF UPDATE

		update_post_meta($post->ID, 'invoice_layout_meta_box', $meta_element_class);
		//print_r($_POST);
	}
}

function invoice_layout_meta_box( $post ) {
	$meta_element_class = get_post_meta($post->ID, 'invoice_layout_meta_box', true); //true ensures you get just one value instead of an array
	?>   
	<!-- <label>Choose the size of the element :  </label> -->
	<?php wp_nonce_field( 'save_myob_nonce', 'myob_invoice_nonce' ); ?>
	<select name="myob_invoice_layout_content" id="myob_invoice_layout_content">
	  <option value="items" <?php selected( $meta_element_class, 'items' ); ?>>Items</option>
	  <option value="service" <?php selected( $meta_element_class, 'service' ); ?>>Service</option>
	  <option value="professional" <?php selected( $meta_element_class, 'professional' ); ?>>Professional</option>
	</select>
	<?php
}

/*
* For myob_sync indicator product list page
*/
// ADDING A CUSTOM COLUMN TITLE TO ADMIN PRODUCTS LIST
add_filter( 'manage_edit-product_columns', 'custom_product_column', 15 );
function custom_product_column( $columns ) {
	//add columns
	$arr = array( 'myob_sync' => __( 'MYOB Status', 'woocommerce' ) );
	array_splice( $columns, 6, 1, $arr );

	return $columns;
}

// ADDING THE DATA FOR EACH PRODUCTS BY COLUMN (EXAMPLE)
add_action( 'manage_product_posts_custom_column' , 'custom_product_list_column_content', 10, 2 );
function custom_product_list_column_content( $column, $product_id ) {

	global $post;

	// HERE get the data from your custom field (set the correct meta key below)
	$sync_data = get_post_meta( $product_id, 'is_synced', true );

	if ( !empty($sync_data) && 'synced' == $sync_data) {

		$sync = 'Synced';

	} else {

		$sync = 'Not Synced';
	}
	
	switch ( $column ) {

		case 'myob_sync': 
		echo esc_attr($sync);
	}
}


/**
* For myob_sync indicator individual product page
*/
add_action( 'add_meta_boxes', 'so_sync_p_meta_box' );
function so_sync_p_meta_box( $post_type ) {

	global $post;
	add_meta_box('so_sync_meta_box', 'MYOB Sync Status', 'sync_myob_indicate_meta_box', $post->post_type, 'side' , 'high');
}


function sync_myob_indicate_meta_box( $post ) {

	$meta_element_class = get_post_meta($post->ID, 'is_synced', true); //true ensures you get just one value instead of an array

	if ( !empty($meta_element_class) && 'synced' == $meta_element_class ) {

		$sync = 'Synced';

	} else {

		$sync = 'Not Synced';
	}
	echo esc_attr($sync);
}
