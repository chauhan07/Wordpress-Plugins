<?php
/**
 * MYOB connector
 *
 * @package WC_MYOB_Integration
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
// ini_set('display_errors', 1);
// ini_set('display_startup_errors', 1);
// error_reporting(E_ALL);

require_once(WC_MYOB_INTEGRATION_PLUGINDIR . '/includes/class-opmc-myob-item-order.php' );
require_once(WC_MYOB_INTEGRATION_PLUGINDIR . '/includes/class-opmc-myob-item-invoice.php' );
require_once(WC_MYOB_INTEGRATION_PLUGINDIR . '/includes/opmc/class-opmc-erp-connector.php' );

if ( ! class_exists( 'Opmc_Myob_Connector' ) ) :
	class Opmc_Myob_Connector extends Opmc_Erp_Connector {


		public $order_batch_process;
		public $mp_order_batch_process;
		public $product_import_process;
		public $import_product_to_myob_process; 


		/**
		* Construct the plugin.
		*/
		public function __construct() {
			$this->http_timeout = 60;

			$config = get_option( 'woocommerce_MYOB_integrations_settings');
			// print_r($config);exit;
			$this->tax_code_new_product = get_option( 'WC_MYOB_tax_code_new_products' );
			$this->tax_code_line_item = get_option( 'WC_MYOB_tax_code_line_items' );

			$this->tax_codes = get_option('WC_MYOB_tax_codes_list');
			$this->freight_tax_code = get_option( 'WC_MYOB_freight_tax_code' );

			$this->client_id = get_option( 'WC_MYOB_client_id' );
			$this->client_secret = get_option( 'WC_MYOB_secret' );
			$this->company_file_id = get_option( 'WC_MYOB_company_file_id' );
			$this->income_account = get_option( 'WC_MYOB_income_account' );
			$this->myob_code = get_option( 'WC_MYOB_code' );
			$this->refresh_token = get_option( 'MYOB_access_refresh_token' );
			$this->access_token = get_option( 'MYOB_access_token' );

			//$this->cftoken = base64_encode('Administrator:');

			// TODO add config variable
			$this->customer_id_prefix = get_option( 'WC_MYOB_customer_id_prefix' );
			$this->guest_customer_display_id = get_option( 'WC_MYOB_guest_customer_display_id' );
			$this->cogs_account = get_option( 'WC_MYOB_cogs_account' );
			$this->asset_account = get_option( 'WC_MYOB_asset_account' );


			$this->tax_code_new_product = isset($config['WC_MYOB_tax_code_new_products']) ? $config['WC_MYOB_tax_code_new_products'] : '';
			$this->tax_code_line_item = isset($config['WC_MYOB_tax_code_line_items']) ? $config['WC_MYOB_tax_code_line_items'] : '';

			$this->freight_tax_code = isset($config['WC_MYOB_freight_tax_code']) ? $config['WC_MYOB_freight_tax_code'] : '';

			$this->company_file_id = isset($config['WC_MYOB_company_file_id']) ? $config['WC_MYOB_company_file_id'] : '';
			$this->income_account = isset($config['WC_MYOB_income_account']) ? $config['WC_MYOB_income_account'] : ''; 
			//$this->myob_code = get_option('WC_MYOB_code');
			//$this->refresh_token = get_option('MYOB_access_refresh_token');
			//$this->access_token = get_option('MYOB_access_token');
						$WC_MYOB_company_file_username = isset($config['WC_MYOB_company_file_username']) ? trim($config['WC_MYOB_company_file_username']) : '';
						$WC_MYOB_company_file_password = isset($config['WC_MYOB_company_file_password']) ? trim($config['WC_MYOB_company_file_password']) : '';
			$this->cftoken = base64_encode($WC_MYOB_company_file_username . ':' . $WC_MYOB_company_file_password);
						//$this->cftoken = base64_encode('Administrator:');
			// TODO add config variable
			$this->customer_id_prefix = isset($config['WC_MYOB_customer_id_prefix']) ? $config['WC_MYOB_customer_id_prefix'] : ''; 
			$this->guest_customer_display_id = isset($config['WC_MYOB_guest_customer_display_id']) ? $config['WC_MYOB_guest_customer_display_id'] : '';
			$this->cogs_account = isset($config['WC_MYOB_cogs_account']) ? $config['WC_MYOB_cogs_account'] : '';
			$this->asset_account = isset($config['WC_MYOB_asset_account']) ? $config['WC_MYOB_asset_account'] : ''; 

			$this->enable_product_create = isset($config['WC_OPMC_enable_product_create']) ? $config['WC_OPMC_enable_product_create'] : 'no'; 
			$this->create_closed_invoices = isset($config['WC_OPMC_create_closed_invoices']) ? $config['WC_OPMC_create_closed_invoices'] : 'no';
			$this->create_order_instead_of_invoice = isset($config['WC_OPMC_create_order_instead_of_invoice']) ? $config['WC_OPMC_create_order_instead_of_invoice'] : 'no';
			$this->create_orders_when_on_hold = isset($config['WC_OPMC_create_orders_when_on_hold']) ? $config['WC_OPMC_create_orders_when_on_hold'] : 'no';
			$this->enable_guest_customer_create = isset($config['WC_OPMC_create_guest_as_customer']) ? $config['WC_OPMC_create_guest_as_customer'] : 'no';
			$this->invoice_id_prefix = isset($config['WC_MYOB_invoice_id_prefix']) ? $config['WC_MYOB_invoice_id_prefix'] : '';

			$this->endpoint = 'https://api.myob.com/accountright/';
			$this->full_endpoint = 'https://api.myob.com/accountright/' . $this->company_file_id;

			$this->http_code = null;

			require_once plugin_dir_path( __FILE__ ) . 'background-processes/class-opmc-order-batch-process.php';
			require_once plugin_dir_path( __FILE__ ) . 'background-processes/class-opmc-product-import-process.php';
			require_once plugin_dir_path( __FILE__ ) . 'background-processes/class-opmc-manual-payment-order-batch-process.php';
			require_once plugin_dir_path( __FILE__ ) . 'background-processes/class-opmc-import-product-to-myob-process.php'; 
			

			$this->order_batch_process = new Opmc_Order_Batch_Process();
			$this->product_import_process = new Opmc_Product_Import_Process();
			$this->mp_order_batch_process = new Opmc_Manual_Payment_Order_Batch_Process();
			$this->import_product_to_myob_process = new Opmc_Import_Product_To_Myob_Process();

			// if (isset($_GET['test'])) {
			// 	$this->import_product_to_myob();
			// } PLUGINS-635

		}

		/**
		* Return true if the required credentials for MYOB access
		* have been defined
		*/
		public function are_credentials_defined() {

			if ( !empty($this->company_file_id)
			&& !empty($this->access_token)
			&& !empty($this->client_id)) {
				return true;
			}

			return false;
		}

		public function admin_notice_error() {
			 $class = 'notice notice-error';
			 $message = 'An error has occurred with an MYOB transaction.';

			  printf( '<div class="%1$s"><p>%2$s</p></div>', esc_attr( $class ), esc_html( $message ) );
		}

		/**
		* Build the HTTP message with the appropriate authentication headers
		*/
		private function create_headers() {

			$x = array(
				'Authorization' => 'Bearer ' . $this->access_token,
				'x-myobapi-key' => $this->client_id,
				'Accept-Encoding' => 'gzip,deflate',
				'x-myobapi-version' => 'v2',
				'scope' => 'CompanyFile',
				'Content-Type' => 'application/json',
				'x-myobapi-cftoken' => $this->cftoken
			);

			return $x;
		}



		/**
		* Wrapper for a generic POST call to MYOB API
		*
		* @return NULL on error
		* @return decoded JSON on success
		* @return false on empty response
		*/
		private function remote_post_json( $uri, $params) {


			if ( ( 600 + get_option( 'WC_MYOB_refresh_token_timestamp' ) ) < time() ) {
				Opmc_Logger::debug( 'Token expired - refreshing' );
				$this->refresh_token();
			}
			$testREQ = array('headers'=> $this->create_headers(),'body'=>json_encode($params),'timeout'=>$this->http_timeout);
			$debugStr = print_r($testREQ, true);
			Opmc_Logger::debug( '[Plugins-1092 HTTP POST Request Sent]' . $debugStr ); 

			$resp = wp_remote_post( $this->endpoint . $this->company_file_id . $uri, array(
				'headers' => $this->create_headers(),
				'body'    => json_encode($params),
				'timeout' => $this->http_timeout
			));

			// error_log('This is custom log');
			// error_log('endpoint ' . $this->endpoint);
			// error_log('company_file_id ' . $this->company_file_id);
			// error_log('uri ' . $uri);
			// error_log('Response received');
			// error_log(print_r($resp, true));
			if ( is_wp_error( $resp ) ) {
				$error_string = $resp->get_error_message();
				echo '<div id="message" class="error"><p>' . esc_html( $error_string ) . '</p></div>';
				Opmc_Logger::error("MYOB remote_post_json: $error_string");

				throw new Opmc_Myob_Exception( "Oops! We had a problem processing your order.  $error_string " );
			}

			$resp_code = $resp['response']['code'];
			//$locationString = $resp['headers']['data']['location'];
			$this->http_code = $resp_code;
			//Opmc_Logger::error('locationString: '.$locationString);

			if ( 200 !== $resp_code && 201 != $resp_code ) {
				Opmc_Logger::error( "MYOB Error $resp_code returned from MYOB server" );
				Opmc_Logger::error($resp);
								
				if ( 401 == $resp_code ) {
					Opmc_Logger::error( 'MYOB 401 returned, attempting to re-authorize connection to MYOB' );

					$x = get_option('WC_MYOB_api_unauthorized_count');
					update_option('WC_MYOB_api_unauthorized_count', $x+1);



					$this->refresh_token();
					return false;
				}

				throw new Opmc_Myob_Exception( "Oops! We had a problem processing your order.  Error code $resp_code occurred." );
			}

			if ( empty($resp['body']) ) {
				return false;
			}

			$x = get_option('WC_MYOB_api_unauthorized_count');
			if (0 < $x) {
				update_option('WC_MYOB_api_unauthorized_count', 0);
			}

			return json_decode($resp['body']);
		}

		
		/**
		* Wrapper for a generic POST call to MYOB API
		*
		* @return NULL on error
		* @return decoded JSON on success
		* @return false on empty response
		*/
		private function remote_put_json( $uri, $params) {


			if ( ( 600 + get_option( 'WC_MYOB_refresh_token_timestamp' ) ) < time() ) {
				Opmc_Logger::debug( 'Token expired - refreshing' );
				$this->refresh_token();
			}

			$resp = wp_remote_request( $this->endpoint . $this->company_file_id . $uri, array(
				'method'  => 'PUT',
				'body'    => json_encode($params),
				'headers' => $this->create_headers(),
				'timeout' => $this->http_timeout
			));

			if ( is_wp_error( $resp ) ) {
				$error_string = $resp->get_error_message();
				echo '<div id="message" class="error"><p>' . esc_html( $error_string ) . '</p></div>';
				Opmc_Logger::debug("MYOB remote_post_json: $error_string");

				throw new Opmc_Myob_Exception( "Oops! We had a problem processing your order.  $error_string " );
			}

			$resp_code = $resp['response']['code'];
			$this->http_code = $resp_code;


			if ( 200 !== $resp_code && 201 != $resp_code ) {
				Opmc_Logger::debug("MYOB Error $resp_code returned from MYOB server");
				Opmc_Logger::debug($resp);

				if ( 401 == $resp_code ) {
					Opmc_Logger::debug('MYOB 401 returned, attempting to re-authorize connection to MYOB');

					$x = get_option('WC_MYOB_api_unauthorized_count');
					update_option('WC_MYOB_api_unauthorized_count', $x+1);

					$this->refresh_token();
					return false;
				}

				throw new Opmc_Myob_Exception( "Oops! We had a problem processing your order.  Error code $resp_code occurred." );
			}

			if ( empty($resp['body']) ) {
				return false;
			}

			$x = get_option('WC_MYOB_api_unauthorized_count');
			if (0 < $x) {
				update_option('WC_MYOB_api_unauthorized_count', 0);
			}

			return json_decode($resp['body']);
		}


		/**
		* Perform a get request to MYOB and return result as JSON
		*
		* @return JSON response
		* @return NULL on error response
		* @return false on empty response
		*/

		private function remote_get_json( $uri, $params = null) {


			if ( ( 600 + get_option( 'WC_MYOB_refresh_token_timestamp' ) )  < time() ) {
				Opmc_Logger::debug( 'Token expired - refreshing' );
				$this->refresh_token();
			}

			$param_list = '';

			if ( null !== $params) {
				$param_list = '?';

				foreach ( $params as $key => $value) {
					$param_list .= $key . '=' . $value;
					$param_list .= '&';
				}

				$param_list = rtrim($param_list, '&');
			}
						
			//Opmc_Logger::debug($uri . $param_list);

			$get_result = wp_remote_get( $uri . $param_list, array(
			'headers' => $this->create_headers(),
			'timeout' => $this->http_timeout
			));

						//Opmc_Logger::debug('See result'); 
						//Opmc_Logger::debug(print_r($get_result,true)); 
			if ( is_wp_error( $get_result ) ) {
				Opmc_Logger::debug('MYOB wp_error on get: ' . $get_result->get_error_message());
				$error_string = $get_result->get_error_message();
				throw new Opmc_Myob_Exception( "Oops! We had a problem processing your order.  $error_string ");
			}


			// handle HTTP error or record not found
			$resp_code = $get_result['response']['code'];
			$this->http_code = $resp_code;

			if ( 200 !== $resp_code && 201 != $resp_code ) {
				Opmc_Logger::debug("MYOB Error $resp_code returned from MYOB server");
				Opmc_Logger::debug($get_result);
				if ( 401 == $resp_code ) {
					Opmc_Logger::debug($get_result);

					$x = get_option('WC_MYOB_api_unauthorized_count');
					update_option('WC_MYOB_api_unauthorized_count', $x+1);

					Opmc_Logger::debug('MYOB 40x returned, attempting to re-authorize connection to MYOB');
					$this->refresh_token();
					return false;
				}



				throw new Opmc_Myob_Exception( "Oops! We had a problem processing your order.  Error code $resp_code occurred." );
			}


			if ( empty($get_result['body']) ) {
				return false;
			}

			$x = get_option('WC_MYOB_api_unauthorized_count');
			if (0 < $x) {
				update_option('WC_MYOB_api_unauthorized_count', 0);
			}

			return json_decode($get_result['body']);
		}


		/**
		 * Generic helper function to get a list of data from the remote MYOB server
		 * using HTTP get
		 *
		 * @param $api - path to API
		 * @param $params - array of parameters to put on GET request
		 * @param $name_field - optional function to populate name field from result data
		 * @param $uid_field - optional function to populate UID field from result data
		 *
		 * @return an array of UID => Name suitable for populating a SELECT control
		 */
		private function get_remote_list( $api, $params = null, callable $name_field = null, callable $uid_field = null, callable $items_array = null ) {

			if (!$this->are_credentials_defined()) {
				return null;
			}

			// define default functions to populate name and UID
			if ( null === $name_field ) {
				$name_field = function( $x) {
					return $x->DisplayID . ' - ' . $x->Name;
				};
			}

			if ( null === $uid_field ) {
				$uid_field = function( $x) {
					return $x->UID;
				};
			}

			if ( null === $items_array ) {
				$items_array = function( $x) {
					return $x->Items;
				};
			}

			$resp = $this->remote_get_json($api, $params);


			// TODO if response is NULL, keep the old value in the cache
			if ( null !== $resp && false !== $resp ) {
				$name = array();
				$uid  = array();

				foreach ($items_array($resp) as $item) {
					$name[]  = $name_field($item);
					$uid[]  = $uid_field($item);
				}
				$x = array_combine($uid, $name);
				return $x;
			}

			return array('');
		}


		public function get_company_file() {
			return $this->get_remote_list($this->endpoint, null, function ( $x) {
				return $x->Name;
			}, function ( $x) {
				return $x->Id;
			}, function ( $x) {
				return $x;
			} );
		}


		public function get_income_accounts() {
			$x = $this->get_remote_list($this->full_endpoint . '/GeneralLedger/Account', array ( '$filter' => "Type eq 'Income' and IsHeader eq false"));
			Opmc_Logger::debug('get_income_accounts' . print_r($x, true));
			return $x;
		}


		public function get_expense_accounts() {
			$x = $this->get_remote_list($this->full_endpoint . '/GeneralLedger/Account', array ( '$filter' => "Type eq 'Expense' and IsHeader eq false"));
			Opmc_Logger::debug('get_expense_accounts' . print_r($x, true));
			return $x;
		}


		public function get_asset_accounts() {
			$x = $this->get_remote_list($this->full_endpoint . '/GeneralLedger/Account', array ( '$filter' => "Classification eq 'Asset' and IsHeader eq false"));
			Opmc_Logger::debug('get_asset_accounts' . print_r($x, true));
			return $x;
		}


		public function get_cogs_accounts() {
			$x = $this->get_remote_list($this->full_endpoint . '/GeneralLedger/Account', array ( '$filter' => "Type eq 'CostOfSales' and IsHeader eq false"));
			Opmc_Logger::debug('get_cogs_accounts' . print_r($x, true));
			return $x;
		}


		public function get_tax_codes() {
			return $this->get_remote_list($this->full_endpoint . '/GeneralLedger/TaxCode', null, function( $x) {
				return $x->Code . ' - ' . $x->Description;
			});
		}


		public function get_job_codes() {
			$filter = 'IsActive eq true';
			$params = array( '$filter' => urlencode($filter) );
			$jobs = $this->remote_get_json( $this->full_endpoint . '/GeneralLedger/Job', $params);
			$job_codes  = array();
			
			if (!empty($jobs)) {
				foreach ($jobs->Items as $key => $job) {
					if (true != $job->IsHeader) {
						$job_codes[$job->UID] = $job->Number;
					}
				}
			}

			return $job_codes;
		}


		public function reload_accounts_list() {
			update_option( 'WC_MYOB_company_file_list', $this->get_company_file() );
			update_option( 'WC_MYOB_income_accounts_list', $this->get_income_accounts() );
			update_option( 'WC_MYOB_expense_accounts_list', $this->get_expense_accounts() );
			update_option( 'WC_MYOB_asset_accounts_list', $this->get_asset_accounts() );
			update_option( 'WC_MYOB_cogs_accounts_list', $this->get_cogs_accounts() );
			update_option( 'WC_MYOB_tax_codes_list', $this->get_tax_codes() );
			update_option( 'WC_MYOB_job_codes_list', $this->get_job_codes() );
		}

		/*
		* cron_schedules
		* execute as cron job function
		*/
		public function refresh_token() {
			Opmc_Logger::debug( 'refresh_token()' );


			if ( get_option( 'MYOB_access_token' ) ) {
				// build up the params for generating token
				$params = array(
				'client_id'				=>	$this->client_id,
				'client_secret'			=>	$this->client_secret,
				'grant_type'			=>	'refresh_token',
				'refresh_token'			=>	get_option('MYOB_access_refresh_token'),
				);

				$query = 'client_id=' . $params['client_id'] .
					'&client_secret=' . $params['client_secret'] .
					'&grant_type=refresh_token' .
					'&refresh_token=' . urlencode(get_option('MYOB_access_refresh_token'));


				// generate token post through api
				$response = wp_remote_post( TOKEN_URI , array(
				'body' => $params
				));

				// CAUTION:  this could probably call remote_post_json but does not do so, due to
				// the risk of an endless loop if that function receives a 401.

				if ( !is_wp_error( $response ) && ( 200 == $response['response']['code'] || 201 == $response['response']['code'] ) ) {
					$tokenData = json_decode($response['body']);

					// update token related data in option table
					update_option('MYOB_access_token', $tokenData->access_token);
					$this->access_token = $tokenData->access_token;
					update_option('MYOB_access_refresh_token', $tokenData->refresh_token);
					update_option('MYOB_access_token_type', $tokenData->token_type);
					update_option('MYOB_access_token_scope', $tokenData->scope);
					update_option('WC_MYOB_refresh_token_timestamp', time() );
					Opmc_Logger::debug( 'Token refresh succeeded' );
				} else {
					Opmc_Logger::debug($response);
					Opmc_Logger::debug( 'Token refresh failed' );
				}
			}
		}




		/**
		* Get the customer UID from MYOB
		*
		* @return null if customer not found
		* @return UID of customer in MYOB if found
		*/
		public function get_erp_customer( $order_id) {

			$order = new WC_Order( $order_id );
			$customer_id = $order->get_customer_id();
			Opmc_Logger::debug('get_customer_id ' . $customer_id);
			$first_name = $order->get_billing_first_name();
			$last_name = $order->get_billing_last_name();
			// handle guest account
			
				
			if ( 0 == $customer_id) {
				if ('yes' == $this->enable_guest_customer_create) {
					$customer = $this->get_customer_with_email($order->get_billing_email());
					if (null != $customer) {
						return $customer;
					}
				}
				
				if ( empty( $this->guest_customer_display_id ) || ctype_space( $this->guest_customer_display_id ) ) {
					$display_id = $this->customer_id_prefix . $order->get_order_number() . '-GUEST';
				} else {
					$string = $this->guest_customer_display_id;
					$display_id = substr($string, 0, 15);
				}
			} else {
				$display_id = $this->customer_id_prefix . $customer_id;
			}

			Opmc_Logger::debug('get_customer ' . $display_id);
			$filter = 'DisplayID eq ' . "'" . $display_id . "'";

			$params = array( '$filter' => urlencode($filter) );
			$cust = $this->remote_get_json( $this->full_endpoint . '/Contact/Customer', $params);

			// TODO add error check

			if ( false !== $cust && null !== $cust && isset($cust->Items) && count($cust->Items) === 1) {
				$cust_uid = $cust->Items[0]->UID;

				Opmc_Logger::debug('Customer ' . $cust_uid . ' found.');
				$res = $cust->Items[0];
				return $res;
			}

			return null;
		}

		public function get_customer_with_email( $email ) {

			$filter = 'Addresses/any(x: x/Email eq ' . "'" . $email . "')";

			$params = array( '$filter' => urlencode($filter) );

			$cust = $this->remote_get_json( $this->full_endpoint . '/Contact/Customer', $params);
			if ( false !== $cust && null !== $cust && isset($cust->Items) && count($cust->Items) > 0) {
				$cust_uid = $cust->Items[0]->UID;
				// print_r($cust_uid);exit;

				Opmc_Logger::debug('Customer ' . $cust_uid . ' found.');
				$res = $cust->Items[0];
				return $res;
			}
			return null;
		}

		/** Create customer in MYOB Account Right
		*
		* @return null if customer not found
		* @return new customer record created
		*/
		public function create_customer( $order_id ) {
			Opmc_Logger::debug('create_customer');

			if ( null === $order_id ) {
				Opmc_Logger::debug('Input is null on create customer');
				return null;
			}

			if ( empty($this->tax_code_new_product) || empty($this->freight_tax_code)) {
				Opmc_Logger::debug('Error: tax codes are not set on create customer');
				return null;
			}

			$order = new WC_Order( $order_id );
						
			// handle guest account
			$customer_id 			= $order->get_customer_id();
			$billing_company 		= $order->get_billing_company();
			$first_name 			= $order->get_billing_first_name();
			$last_name 				= $order->get_billing_last_name();
			$emailId 				= $order->get_billing_email();
			$get_billing_address_1 	= $order->get_billing_address_1();
			$get_billing_city 		= $order->get_billing_city();
			$get_billing_state 		= $order->get_billing_state();
			$get_billing_postcode 	= $order->get_billing_postcode();
			$get_billing_country 	= $order->get_billing_country();
			$get_billing_phone 		= $order->get_billing_phone();

			if ( 0 === $customer_id) {
				if ( empty( $this->guest_customer_display_id ) || ctype_space( $this->guest_customer_display_id ) ) {

					$string                = $this->customer_id_prefix . $order->get_order_number() . '-GUEST';
					$display_id            = substr($string, 0, 15);

				} else {

					$string                = $this->guest_customer_display_id;
					$display_id            = substr($string, 0, 15);
					$first_name            = 'Guest';
					$last_name             = 'guest';
					$emailId               = get_option( 'admin_email' );
					$get_billing_address_1 = get_option( 'woocommerce_store_address' );
					$get_billing_city      = get_option( 'woocommerce_store_city' );
					$get_billing_country   = get_option( 'woocommerce_default_country' );
					$get_billing_country   = explode(':', $get_billing_country);
					$get_billing_state     = $get_billing_country[1];
					$get_billing_postcode  = get_option( 'woocommerce_store_postcode' );
					$get_billing_country   = $get_billing_country[0];
				}
			} else {
				$display_id = $this->customer_id_prefix . $customer_id;
			}

			// TODO remove TaxCode from customer
			$params = array(
				'LastName'           => $last_name,
				'FirstName'          => $first_name,
				'DisplayID'          => $display_id,
				'SellingDetails'     => array(
					'Terms'			 => array(
						'PaymentIsDue' 	=> 'PrePaid'
						),
					'TaxCode'        => array(
						'UID'        => $this->tax_code_new_product
						),
					'FreightTaxCode' => array(
						'UID'        => $this->freight_tax_code
						)
					),
				'Addresses' => array(
					array(
						'Location'	=> 1,
						'Street' 	=> $get_billing_address_1,
						'City'		=> $get_billing_city,
						'State'		=> $get_billing_state,
						'PostCode'	=> $get_billing_postcode,
						'Country'	=> $get_billing_country,
						'Email'		=> $emailId,
						'Phone1'	=> $get_billing_phone,
						'ContactName' => $first_name . ' ' . $last_name
						),
					)
				);

			// For customer designation type
			$wc_setting = get_option('woocommerce_MYOB_integrations_settings');

			$WC_OPMC_set_default_customer_designation = $wc_setting['WC_OPMC_set_default_customer_designation'];

			if (isset($billing_company) && 'no' == $WC_OPMC_set_default_customer_designation ) {

				$params['IsIndividual'] = false;
				$params['CompanyName'] = $first_name . ' ' . $last_name;
				
			} else {
				$params['IsIndividual'] = true;
			} //

			$resp = $this->remote_post_json('/Contact/Customer?returnBody=true', $params);

			Opmc_Logger::debug('Create customer response');
			Opmc_Logger::debug(print_r($resp, true));

			if (null !== $resp && false != $resp) {
				return $resp;
			}

			return null;
		}


		/**
		* Update the address of a customer based on their information in a WooCommerce Order
		*
		* TODO: finish implemention - issues with MYOB API for update
		*/
		public function update_customer_address( $order_id, $customer_record ) {

			return null;

			Opmc_Logger::debug('Updating customer address');

			if ( null === $order_id || empty($customer_record) ) {
				Opmc_Logger::debug('Input is null on update customer');
				return null;
			}

			$order = new WC_Order( $order_id );

			$displayId = $this->customer_id_prefix . $order->get_customer_id();

			$row_version = $customer_record->RowVersion + 1;

			$display_id = $this->customer_id_prefix . $order->get_customer_id();


			$params = array (
				'UID'	=> $customer_record->UID,
				'DisplayID' => $customer_record->DisplayID,
				'LastName'			=> $customer_record->LastName,
				'FirstName' 		=> $customer_record->FirstName,
				'SellingDetails'     => array(
					'Terms'			 => array(
						'PaymentIsDue' 	=> 'PrePaid'
						),
					'TaxCode'        => array(
						'UID'        => $this->tax_code_new_product
						),
					'FreightTaxCode' => array(
						'UID'        => $this->freight_tax_code
						)
					),
				'RowVersion' 		=> 1,
				'Addresses' => array(
					array(
						'Location'	=> 1,
						'Street' 	=> $order->get_billing_address_1(),
						'City'		=> $order->get_billing_city(),
						'State'		=> $order->get_billing_state(),
						'PostCode'	=> $order->get_billing_postcode(),
						'Country'	=> $order->get_billing_country(),
						'Email'		=> $order->get_billing_email(),
						'Phone1'	=> $order->get_billing_phone(),
						'ContactName' => $customer_record->FirstName . ' ' . $customer_record->LastName
						),
					)
			);

			// For customer designation type

			$wc_setting = get_option('woocommerce_MYOB_integrations_settings');

			$WC_OPMC_set_default_customer_designation = $wc_setting['WC_OPMC_set_default_customer_designation'];
			if (!empty($WC_OPMC_set_default_customer_designation) && 'yes' == $WC_OPMC_set_default_customer_designation) {

				$params['IsIndividual'] = true;

			} else {
				$params['IsIndividual'] = false;
				$params['CompanyName'] = $first_name . ' ' . $last_name;
			} //

			$resp = $this->remote_put_json('/Contact/Customer', $params);


			if (null !== $resp && false != $resp) {
				return $resp->UID;
			}

			return null;


		}


		/**
		* Create a new product in MYOB based on a line item in a WooCommerce order
		*
		*/
		public function create_erp_inventory_item( $order_item) {
			Opmc_Logger::debug('create_erp_inventory_item');

			$product = $order_item->get_product();
						$productId = $product->get_id();
			$name = $product->get_name();
			$sku = $product->get_sku();
			$price = $product->get_regular_price();
			$qty = $product->get_stock_quantity();  
						$cartQty = $order_item['qty'];
			$myob_product = array( 
							'Number' => $sku,
							'Name' => $name,
							'IsActive' => 'true',
							'IsSold' => 'true',
							'IncomeAccount' => array( 
								'UID' => $this->income_account
							),
							'SellingDetails' => array(
								'BaseSellingPrice' => $price,
								'SellingUnitOfMeasure'=> null,
								'ItemsPerSellingUnit'=> null,
								'IsTaxInclusive'=> true,
								'CalculateSalesTaxOn'=> 'ActualSellingPrice',
								'TaxCode' => array(
									'UID' => $this->tax_code_new_product
								)
							),
						);

			/* if stock is selected to be managed in Woo, the item will be created as
			* inventoried in MYOB.    Note that you cannot convert a non-inventoried item
			* to inventories in MYOB once it has been created.
			*/
			if ( $product->managing_stock() ) {

				if ( empty( $this->cogs_account ) || empty( $this->asset_account ) ) {
					Opmc_Logger::error( 'Cost of Sales and Asset Accounts must be set for inventoried product' );
				}

				$myob_product[ 'IsInventoried' ] = 'true';

				$myob_product[ 'CostOfSalesAccount' ] = array( 'UID' => $this->cogs_account );

				$myob_product[ 'AssetAccount' ] = array( 'UID' => $this->asset_account );

				if ( $qty < 1 ) {
									$qty = 1;
				} else {
					$qty = $qty + $cartQty;
				}
				$myob_product[ 'QuantityOnHand' ] = $qty;
				$myob_product[ 'QuantityAvailable' ] = $qty;
			}
			Opmc_Logger::debug('create product Here is the cart qty' . $cartQty);
			Opmc_Logger::debug( $myob_product );
			Opmc_Logger::debug('create product end');
			$res = $this->remote_post_json( '/Inventory/Item', $myob_product );


			$item = $this->get_erp_inventory_items( $sku );

			$product_uid = $item[0]->UID;

			/*
			*  Adjust inventory
			*/
			if ( $product->managing_stock() ) {
				$query = array (
				'Date' => gmdate('Y-m-d') . 'T' . gmdate('H:i:s'),
				'Memo' => 'Created by WooCommerce',
				'Lines' => array (
					array (
						'Quantity' => $qty,
						'Item' => array (
							'UID' => $product_uid,
						),
						'Account' => array (
							'UID' => $this->asset_account,
						),
					),
				),
				);

				Opmc_Logger::debug( $query );


				$res = $this->remote_post_json( '/Inventory/Adjustment', $query );

			}

			// TODO handle result codes

		}


		/**
		* Fetch MYOB account right Inventory Items
		*
		* @param $skus - Array of SKUS to retrieve, or string for single SKU.  If null will
		*				 return a list of all skus in the MYOB system.
		*
		* @return an array of product records from MYOB
		*/
		public function get_erp_inventory_items( $skus = null) {
			Opmc_Logger::debug('get_erp_inventory_items');

			$items = null;
			$params = null;


			if ( null !== $skus ) {
				if ( is_array($skus) ) {
					$filter = 'Number eq ' . "'" . $skus[0] . "'";

					$i = 0;
					foreach ( $skus as $sku ) {
						if ( 0 != $i ) {
							$filter .= ' or Number eq ' . "'" . $sku . "'";
						}
						$i++;
					}
				} else {
					$filter = 'Number eq ' . "'" . $skus . "'";
				}

				$params = array( '$filter' => urlencode($filter) );
			}

			$items[] = $this->remote_get_json( $this->full_endpoint . '/Inventory/Item', $params);
			
			if (null != $items) {
				if ( 0 === $items[0]->Count ) {
					return null;
				}

				return $items[0]->Items;
			} else {
				return null;
			}
		}



		/**
		* Return a single MYOB inventory item from an array of MYOB inventory items as returned by
		* the get_erp_inventory_items function
		*
		* @param $sku - the SKU to search for in the result set
		* @param $myob_items - the result set to search
		*
		* @return MYOB inventory item object if found
		* @return null if not found
		*/
		private function get_myob_item_from_sku( $sku, $myob_items) {
			if (null != $myob_items) {
				foreach ( $myob_items as $x ) {
					if ( $x->Number == $sku ) {
						return $x;
					}
				}
			}
			return null;
		}

		/**
		* Ensure that all SKUs in the order exist in MYOB.   If not, then create them.
		*
		*/
		public function verify_myob_inventory_items( $order_id) {
			Opmc_Logger::debug('verify_erp_inventory_items');

			$order = new WC_Order( $order_id );
			$order_items = $order->get_items();
			$item_uid = array();
			$line = array();
			$i = 0;

			//
			// Build list of skus in the Woo order
			$skus = array();

			foreach ($order_items as $item_data) {
				$product = $item_data->get_product();
				$sku = $product->get_sku();

				$skus[] = $sku;
			}


			// Get the product records for all the skus we assembled in the list previously
			$myob_items = $this->get_erp_inventory_items($skus);

			if ( null !== $myob_items ) {
				Opmc_Logger::debug('Found ' . count($myob_items) . ' items of ' . count($order_items) . ' requested.');
			} else {
				Opmc_Logger::debug('Found no items of ' . count($order_items) . ' requested.');
			}

			// iterate through the list of skus and find any that are in the Woo order
			// but are not in MYOB.  Create any of the missing items in MYOB.

			foreach ($skus as $sku) {
				$found = 0;

				if ( null !== $myob_items ) { // if nothing matched MYOB then don't even search
					foreach ($myob_items as $item) {
						if ( $item->Number == $sku ) {
							$found++;
						}
					}
				}

				if ( 0 == $found ) {
					if ('yes' == $this->enable_product_create) {
						Opmc_Logger::debug("SKU $sku not found, creating");
						// sku not found, find it in the Woo order array and then create in MYOB
						foreach ($order_items as $key => $woo_item) {
							$product = $woo_item->get_product();
														Opmc_Logger::debug($woo_item);
							if ( $sku == $product->get_sku() ) {
								// we found the data in the Woo order, create in MYOB
								$this->create_erp_inventory_item($woo_item);
							}

						}
					}
				}
			}

			return $this->get_erp_inventory_items($skus);
		}


		// /**
		//  * Creates either a MYOB order or invoice from WooCommerce upon a completed payment.
		//  * 
		//  * @param $order_id - The id for the WooCommerce order.
		//  */ 
		// public function order_from_payment_complete_hook( $order_id) {
		// 	Opmc_Logger::debug("ORDER WITH ID $order_id RECEIVED FROM woocommerce_payment_complete hook");
		// 	$this->add_myob_order_to_queue($order_id);
		// }


		/**
		 * Creates either a MYOB order or invoice from WooCommerce upon an order's status changing.
		 * 
		 * Checks for:
		 * 	   'pending' to 'on-hold'
		 * 	   'pending' to 'processing'.
		 * 
		 * @param $order_id   - The id for the WooCommerce order.
		 * @param $old_status - The status of the WooCommerce order before the update.
		 * @param $new_status - The status of the WooCommerce order after the update.
		 */ 
		public function order_from_status_transition_hook( $order_id, $old_status, $new_status) {
			Opmc_Logger::debug("ORDER WITH ID $order_id RECEIVED FROM woocommerce_order_status_changed");
			Opmc_Logger::debug("Order $order_id status changed from $old_status to $new_status");

			if ('pending' == $old_status && 'on-hold' == $new_status && 'yes' == $this->create_orders_when_on_hold) {
				if ( !is_null( WC()->cart ) ) {
					WC()->cart->empty_cart();
				}
				$this->add_myob_mp_order_to_queue($order_id);
			} else if ('pending' == $old_status && 'processing' == $new_status) {
				if ( !is_null( WC()->cart ) ) {
					WC()->cart->empty_cart();
				}
				$this->add_myob_order_to_queue($order_id);
			}
			// } else if ('on-hold' == $old_status && 'processing' == $new_status) {
			// 	$this->add_myob_order_to_queue($order_id); // TODO: Convert MYOB order to closed invoice.
			// } else if ('on-hold' == $old_status && 'completed'  == $new_status) {
			// 	$this->add_myob_order_to_queue($order_id); // TODO: Convert MYOB order to closed invoice.
			// } 
		}


		/**
		 * Function to sync an order to MYOB when the the resync_order_to_myob order action is triggered.
		 */ 
		public function resync_order_to_myob( $wc_order ) {
			Opmc_Logger::debug('Resyncing order with id: ' . $wc_order->get_id());

			$this->add_myob_order_to_queue($wc_order->get_id());

		}


		/**
		 * Takes the tax class for a single line item in WooCommerce and converts it to a MYOB tax code.
		 * Note: in WooCommerce orders, the default tax class (GST) is an empty '',
		 *       and this function is extensible to other tax codes.
		 * 
		 * @param $wc_tax_class - The tax class for a given line item within a WooCommerce order. 
		 */ 
		public function convert_wc_tax( $wc_tax_class) {
			
			// List the MYOB tax code UIDs to map to wc_tax_class.
			$myob_tax_codes = array();
			foreach ($this->tax_codes as $code => $name) {
				$myob_tax_codes[] = $code;
			}

			// Determine MYOB tax code to return based on wc_tax_class.
			$myob_tax_code;
			if ( '' == $wc_tax_class ) {
				$myob_tax_code = $myob_tax_codes[5];
			} else if ('zero-rate' == $wc_tax_class) {
				$myob_tax_code = $myob_tax_codes[3];
			} else {
				$myob_tax_code = $this->tax_code_line_item;
			} 
			// TODO: extend to support other tax classes.

			Opmc_Logger::debug("Value of wc_tax_class: $wc_tax_class");
			Opmc_Logger::debug("Value of myob_tax_code: $myob_tax_code");

			return $myob_tax_code;
		}



		/**
		* Create an invoice in MYOB account right
		* IEEE802.11 was here
		*/
		public function create_invoice( $order_id, $customer_uid) {
			Opmc_Logger::debug("MYOB_create_invoice $order_id $customer_uid");
			$order = wc_get_order( $order_id );
			$order_items = $order->get_items();

			Opmc_Logger::debug('=======================================================================================================================');
			Opmc_Logger::debug('Printing WC_Order items from get_items');
			Opmc_Logger::debug(print_r($order_items, true));
			Opmc_Logger::debug('=======================================================================================================================');

			// Ensure all line items exist in MYOB, if not, create skeleton product records
			$myob_items = $this->verify_myob_inventory_items($order_id);

			Opmc_Logger::debug('=======================================================================================================================');
			Opmc_Logger::debug('Creating MYOB Invoice Object.....');
			Opmc_Logger::debug('=======================================================================================================================');

			//
			// Create an invoice object to build the POST data
			//
			$invoice = new Opmc_Myob_Item_Invoice($order, $order_id, $customer_uid, $this->freight_tax_code, $myob_items);

			Opmc_Logger::debug('=======================================================================================================================');
			Opmc_Logger::debug('Created MYOB Invoice Object!');
			Opmc_Logger::debug('=======================================================================================================================');


			Opmc_Logger::debug('=======================================================================================================================');
			Opmc_Logger::debug('Adding line items to invoice.....');
			Opmc_Logger::debug('=======================================================================================================================');

			$get_invoice_type = array();
			// Add the line items to the invoice
			foreach ($order_items as $item_id => $item_data) {
				$product_id = $item_data->get_product_id();
				$get_invoice_type[] = get_post_meta( $product_id, 'invoice_layout_meta_box');
			}

			$invoice_type = array_column($get_invoice_type, '0');
			$wc_settings =  get_option('woocommerce_MYOB_integrations_settings');
			$default_invoice_type_setting = $wc_settings['WC_MYOB_invoice_type'];
			Opmc_Logger::debug('default_invoice_type_setting');
			Opmc_Logger::debug($default_invoice_type_setting);

			foreach ($order_items as $item_id => $item_data) {
				$myob_tax = $this->convert_wc_tax($item_data->get_tax_class());
				if (( in_array('items', $invoice_type) && in_array('service', $invoice_type) ) 
					|| ( in_array('items', $invoice_type) && in_array('professional', $invoice_type) )
					|| ( in_array('service', $invoice_type) && in_array('professional', $invoice_type) )
					|| ( in_array('service', $invoice_type) && in_array('items', $invoice_type) )
					|| ( in_array('professional', $invoice_type) && in_array('items', $invoice_type) )
					|| ( in_array('professional', $invoice_type) && in_array('service', $invoice_type) )) {

					if (!empty($default_invoice_type_setting)) {

						if ('items' == $default_invoice_type_setting) {

							$invoice->add_line_item($item_id, $item_data, $myob_tax);
						} elseif ('service' == $default_invoice_type_setting) {
							$invoice->add_line_service($item_id, $item_data, $myob_tax);

						} elseif ('professional' == $default_invoice_type_setting) {
							$invoice->add_line_professional($item_id, $item_data, $myob_tax);
						} else {
							$invoice->add_line_item($item_id, $item_data, $myob_tax);
						}	
					} else {
						$invoice->add_line_item($item_id, $item_data, $myob_tax);
					}

				} elseif (in_array('items', $invoice_type)) {

					$invoice->add_line_item($item_id, $item_data, $myob_tax);

				} elseif (in_array('service', $invoice_type)) {

					$invoice->add_line_service($item_id, $item_data, $myob_tax);

				} elseif (in_array('professional', $invoice_type)) {

					$invoice->add_line_professional($item_id, $item_data, $myob_tax);

				} else {

					$invoice->add_line_item($item_id, $item_data, $myob_tax);
				}
			}

			Opmc_Logger::debug('=======================================================================================================================');
			Opmc_Logger::debug('Added line items to invoice!');
			Opmc_Logger::debug('=======================================================================================================================');

			$invoice->set_address();

			$leave_open = true;

			if (true === $leave_open) {
				$invoice->status = 'Open';
			} else {
				$invoice->status = 'Closed';
			}

			Opmc_Logger::debug('=======================================================================================================================');
			Opmc_Logger::debug('Generating invoice post data.....');
			Opmc_Logger::debug('=======================================================================================================================');

			$post_data = $invoice->generate_post_data(); 

			Opmc_Logger::debug('=======================================================================================================================');
			Opmc_Logger::debug('Generated invoice post data!');
			Opmc_Logger::debug('=======================================================================================================================');

			$invoice_date = $post_data['Date'];

			Opmc_Logger::debug( $post_data );
			Opmc_Logger::debug( 'get_invoice_type' );
			Opmc_Logger::debug($get_invoice_type);

			if (( in_array('items', $invoice_type) && in_array('service', $invoice_type) ) 
				|| ( in_array('items', $invoice_type) && in_array('professional', $invoice_type) )
				|| ( in_array('service', $invoice_type) && in_array('professional', $invoice_type) )
				|| ( in_array('service', $invoice_type) && in_array('items', $invoice_type) )
				|| ( in_array('professional', $invoice_type) && in_array('items', $invoice_type) )
				|| ( in_array('professional', $invoice_type) && in_array('service', $invoice_type) )) {

				if (!empty($default_invoice_type_setting)) {

					if ('items' == $default_invoice_type_setting) {
						$apiurl = '/Sale/Invoice/Item';
						update_post_meta( $order_id, 'invoice_type', 'items' );
						Opmc_Logger::debug( 'default_invoice_type Calling /Sale/Invoice/Item' );

					} elseif ('service' == $default_invoice_type_setting) {
							 
						$apiurl = '/Sale/Invoice/Service';
						update_post_meta( $order_id, 'invoice_type', 'service' );
						Opmc_Logger::debug( 'default_invoice_type Calling /Sale/Invoice/service' );

					} elseif ('professional' == $default_invoice_type_setting) {	

						$apiurl = '/Sale/Invoice/Professional';
						update_post_meta( $order_id, 'invoice_type', 'professional' );
						Opmc_Logger::debug( 'default_invoice_type Calling /Sale/Invoice/Professional' );

					} else {
							
						$apiurl = '/Sale/Invoice/Item';
						update_post_meta( $order_id, 'invoice_type', 'items' );
						Opmc_Logger::debug( 'default_invoice_type Calling /Sale/Invoice/Item' );
					}	
				} else {
					$apiurl = '/Sale/Invoice/Item';
					update_post_meta( $order_id, 'invoice_type', 'items' );
				}

			} elseif (in_array('item', $invoice_type)) {
				$apiurl = '/Sale/Invoice/Item';
				update_post_meta( $order_id, 'invoice_type', 'items' );
				Opmc_Logger::debug( 'Calling /Sale/Invoice/Item' );

			} elseif (in_array('service', $invoice_type)) {
				$apiurl = '/Sale/Invoice/Service';
				update_post_meta( $order_id, 'invoice_type', 'service' );
				Opmc_Logger::debug( 'Calling /Sale/Invoice/Service' );

			} elseif (in_array('professional', $invoice_type)) {
				$apiurl = '/Sale/Invoice/Professional';
				update_post_meta( $order_id, 'invoice_type', 'professional' );
				Opmc_Logger::debug( 'Calling /Sale/Invoice/Professional' );

			} else {
				$apiurl = '/Sale/Invoice/Item';
				update_post_meta( $order_id, 'invoice_type', 'items' );
				Opmc_Logger::debug( 'Calling /Sale/Invoice/Item' );
			}
			$response = $this->remote_post_json( $apiurl, $post_data);

			Opmc_Logger::debug(print_r($response, true));
			
			if ( !is_null( WC()->cart ) ) {
				WC()->cart->empty_cart();
			}

			$config = get_option( 'woocommerce_MYOB_integrations_settings');
			$this->create_closed_invoices = isset($config['WC_OPMC_create_closed_invoices']) ? $config['WC_OPMC_create_closed_invoices'] : 'no';

			Opmc_Logger::debug('=======================================================================================================================');
			Opmc_Logger::debug('Value of isset(config[WC_OPMC_create_closed_invoices]): ' . isset($config['WC_OPMC_create_closed_invoices']));
			Opmc_Logger::debug('Value of config[WC_OPMC_create_closed_invoices]: ' . $config['WC_OPMC_create_closed_invoices']);
			Opmc_Logger::debug('Value of create_closed_invoices: ' . $this->create_closed_invoices);
			Opmc_Logger::debug('=======================================================================================================================');

			Opmc_Logger::debug('=========================================================================================================');
			Opmc_Logger::debug('POST REQUEST BODY (OPMC Invoice)');
			Opmc_Logger::debug(print_r($invoice, true));
			Opmc_Logger::debug('=========================================================================================================');

			//Fetch created invoice with invoice number
			$invoice_data = $this->fetch_invoice($order_id, $invoice_date);
			if (null != $invoice_data) {
				if ('yes' == $this->create_closed_invoices) {
					$this->create_customer_payment( $order_id, $invoice_data);
				}
			}
		}


		/**
		 * Create an MYOB order
		 */
		public function create_order( $order_id, $customer_uid) {
			Opmc_Logger::debug("MYOB_create_order $order_id $customer_uid");

			$wc_order = wc_get_order( $order_id );
			$order_items = $wc_order->get_items();


			// Ensure all line items exist in MYOB, if not, create skeleton product records
			$myob_items = $this->verify_myob_inventory_items($order_id);

			Opmc_Logger::debug('==================================================================================================');
			Opmc_Logger::debug('Creating new Opmc_Myob_Item_Order object.....');
			Opmc_Logger::debug('==================================================================================================');


			// Create an order object to build the POST data
			$myob_order = new Opmc_Myob_Item_Order($wc_order, $order_id, $customer_uid, $this->freight_tax_code, $myob_items);

			Opmc_Logger::debug('==================================================================================================');
			Opmc_Logger::debug('Created new Opmc_Myob_Item_Order object!');
			Opmc_Logger::debug('==================================================================================================');



			Opmc_Logger::debug('==================================================================================================');
			Opmc_Logger::debug('Adding line items to Opmc_Myob_Item_Order object.....');
			Opmc_Logger::debug('==================================================================================================');

			$get_invoice_type = array();
			// Add the line items to the invoice
			foreach ($order_items as $item_id => $item_data) {
				$product_id = $item_data->get_product_id();
				$get_invoice_type[] = get_post_meta( $product_id, 'invoice_layout_meta_box');
			}

			$invoice_type = array_column($get_invoice_type, '0');
			$wc_settings =  get_option('woocommerce_MYOB_integrations_settings');
			$default_invoice_type_setting = $wc_settings['WC_MYOB_invoice_type'];
			Opmc_Logger::debug('default_invoice_type_setting');
			Opmc_Logger::debug($default_invoice_type_setting);

			foreach ($order_items as $item_id => $item_data) {
				$myob_tax = $this->convert_wc_tax($item_data->get_tax_class());
				if (( in_array('items', $invoice_type) && in_array('service', $invoice_type) ) 
					|| ( in_array('items', $invoice_type) && in_array('professional', $invoice_type) )
					|| ( in_array('service', $invoice_type) && in_array('professional', $invoice_type) )
					|| ( in_array('service', $invoice_type) && in_array('items', $invoice_type) )
					|| ( in_array('professional', $invoice_type) && in_array('items', $invoice_type) )
					|| ( in_array('professional', $invoice_type) && in_array('service', $invoice_type) )) {

					if (!empty($default_invoice_type_setting)) {

						if ('items' == $default_invoice_type_setting) {

							$myob_order->add_line_item($item_id, $item_data, $myob_tax);
						} elseif ('service' == $default_invoice_type_setting) {
							$myob_order->add_line_service($item_id, $item_data, $myob_tax);

						} elseif ('professional' == $default_invoice_type_setting) {
							$myob_order->add_line_professional($item_id, $item_data, $myob_tax);
						} else {
							$myob_order->add_line_item($item_id, $item_data, $myob_tax);
						}	
					} else {
						$myob_order->add_line_item($item_id, $item_data, $myob_tax);
					}

				} elseif (in_array('items', $invoice_type)) {

					$myob_order->add_line_item($item_id, $item_data, $myob_tax);

				} elseif (in_array('service', $invoice_type)) {

					$myob_order->add_line_service($item_id, $item_data, $myob_tax);

				} elseif (in_array('professional', $invoice_type)) {

					$myob_order->add_line_professional($item_id, $item_data, $myob_tax);

				} else {

					$myob_order->add_line_item($item_id, $item_data, $myob_tax);
				}
			}

			Opmc_Logger::debug('==================================================================================================');
			Opmc_Logger::debug('Added line items to Opmc_Myob_Item_Order object!');
			Opmc_Logger::debug('==================================================================================================');


			Opmc_Logger::debug('==================================================================================================');
			Opmc_Logger::debug('Adding address to Opmc_Myob_Item_Order object.....');
			Opmc_Logger::debug('==================================================================================================');

			$myob_order->set_address();

			Opmc_Logger::debug('==================================================================================================');
			Opmc_Logger::debug('Added address to Opmc_Myob_Item_Order object!');
			Opmc_Logger::debug('==================================================================================================');


			$leave_open = true;

			if (true === $leave_open) {
				$myob_order->status = 'Open';
			} else {
				$myob_order->status = 'Closed';
			}


			Opmc_Logger::debug('==================================================================================================');
			Opmc_Logger::debug('Generating post data for Opmc_Myob_Item_Order object.....');
			Opmc_Logger::debug('==================================================================================================');


			$post_data = $myob_order->generate_post_data();

			Opmc_Logger::debug('==================================================================================================');
			Opmc_Logger::debug('Generated post data for Opmc_Myob_Item_Order object!');
			Opmc_Logger::debug('==================================================================================================');
			
			if (( in_array('items', $invoice_type) && in_array('service', $invoice_type) ) 
				|| ( in_array('items', $invoice_type) && in_array('professional', $invoice_type) )
				|| ( in_array('service', $invoice_type) && in_array('professional', $invoice_type) )
				|| ( in_array('service', $invoice_type) && in_array('items', $invoice_type) )
				|| ( in_array('professional', $invoice_type) && in_array('items', $invoice_type) )
				|| ( in_array('professional', $invoice_type) && in_array('service', $invoice_type) )) {

				if (!empty($default_invoice_type_setting)) {

					if ('items' == $default_invoice_type_setting) {

						$apiurl = '/Sale/Order/Item';
						Opmc_Logger::debug( 'default_invoice_type Calling /Sale/Invoice/Item' );

					} elseif ('service' == $default_invoice_type_setting) {
						$apiurl = '/Sale/Order/Service';
						Opmc_Logger::debug( 'default_invoice_type Calling /Sale/Invoice/service' );

					} elseif ('professional' == $default_invoice_type_setting) {
						$apiurl = '/Sale/Order/Professional';
						Opmc_Logger::debug( 'default_invoice_type Calling /Sale/Invoice/Professional' );

					} else {
							
						$apiurl = '/Sale/Order/Item';
						Opmc_Logger::debug( 'default_invoice_type Calling /Sale/Invoice/Item' );
					}	
				} else {
					$apiurl = '/Sale/Order/Item';
				}

			} elseif (in_array('item', $invoice_type)) {

				$apiurl = '/Sale/Order/Item';
				Opmc_Logger::debug( 'Calling /Sale/Invoice/Item' );

			} elseif (in_array('service', $invoice_type)) {

				$apiurl = '/Sale/Order/Service';
				Opmc_Logger::debug( 'Calling /Sale/Invoice/Service' );

			} elseif (in_array('professional', $invoice_type)) {

				$apiurl = '/Sale/Order/Professional';
				Opmc_Logger::debug( 'Calling /Sale/Invoice/Professional' );

			} else {

				$apiurl = '/Sale/Order/Item';
				Opmc_Logger::debug( 'Calling /Sale/Invoice/Item' );
			}
			$response = $this->remote_post_json( $apiurl, $post_data);
			Opmc_Logger::debug( 'Calling /Sale/Order/Item' );
			Opmc_Logger::debug(print_r($response, true));

			if ( !is_null( WC()->cart ) ) {
				WC()->cart->empty_cart();
			}
		}

		/**
		 * Enqueue order for background processing.
		 */ 
		public function add_myob_order_to_queue( $order_id ) {
			$this->order_batch_process->push_to_queue( $order_id );
			$this->order_batch_process->save()->dispatch();			
		}


		/**
		 * Enqueue order for background processing from manual payment (mp).
		 */ 
		public function add_myob_mp_order_to_queue( $order_id ) {
			$this->mp_order_batch_process->push_to_queue( $order_id );
			$this->mp_order_batch_process->save()->dispatch();
		}



		public function create_order_for_on_hold_orders( $order_id ) {
			Opmc_Logger::debug('CREATING ORDER FOR AN ON-HOLD ORDER');
			try {
				// Find the customer and create if not found
				$customer = $this->get_erp_customer( $order_id );
				Opmc_Logger::debug(print_r($customer, true));

				if ( null === $customer || null === $customer->UID ) {
					$customer = $this->create_customer( $order_id );
					$customer_uid = $customer->UID;
				} else {
					$this->update_customer_address( $order_id, $customer );
				}

				if ( null !== $customer->UID ) {
					try {

						$order = $this->create_order( $order_id, $customer->UID);

					} catch (Opmc_Myob_Exception $e) {

						$order = new WC_Order( $order_id );
						$note = 'Unable to create invoice with error : ' . $e->getMessage();
						$order->add_order_note($note);
						$this->send_text_mail_to_admin($order_id);
						
					} catch (Throwable $e) {

						$order = new WC_Order( $order_id );
						$note = 'Unable to create invoice with error : ' . $e->getMessage();
						$order->add_order_note($note);
						$this->send_text_mail_to_admin($order_id);
						
					}
				} else {
					$this->create_order_note($order_id, 'Customer UID Not Found');
				}

			} catch (Opmc_Myob_Exception $e) {
				$this->create_order_note($order_id, $e->getMessage());
			} catch (Throwable $e) {
				$this->create_order_note($order_id, $e->getMessage());
			}
		}



		/**
		* Place the order in MYOB.   Will create a new customer record if the customer (identified by email address)
		* is not in MYOB.
		*/
		public function place_order( $order_id, $has_manual_payment = false ) {

			$config = get_option( 'woocommerce_MYOB_integrations_settings');
			$this->create_order_instead_of_invoice = isset($config['WC_OPMC_create_order_instead_of_invoice']) ? $config['WC_OPMC_create_order_instead_of_invoice'] : 'no';

			Opmc_Logger::debug("Creating order $order_id");
			if (is_int($order_id) == false) {
				if (get_class($order_id) == 'WC_Subscription') {

					Opmc_Logger::debug('Subscription detected');
					/*
					The action that calls this function when a subscription renewal payment is made has 2 parameters: WC_subscription and WC_order so it will call this twice.
					The subscription input for this order causes it to crash while the order input will work fine.
					As a result if a WC_subscription is detected just end the function and let the WC_order function call do allthe work.
					*/
					return;
				}
			}

			try {

				// Find the customer and create if not found
				$customer = $this->get_erp_customer( $order_id );
				Opmc_Logger::debug(print_r($customer, true));

				if ( null === $customer || null === $customer->UID ) {
					$customer = $this->create_customer( $order_id );
					$customer_uid = $customer->UID;
				} else {
					$this->update_customer_address( $order_id, $customer );
				}

				// create the invoice
				if ( null !== $customer->UID ) {

					try {

						if ('yes' == $this->create_order_instead_of_invoice || $has_manual_payment) {
							$order = $this->create_order( $order_id, $customer->UID);
						} else {
							$invoice = $this->create_invoice( $order_id, $customer->UID );
						}
					} catch (Opmc_Myob_Exception $e) {

						$order = new WC_Order( $order_id );

						$note;
						if ('yes' == $this->create_order_instead_of_invoice) {
							Opmc_Logger::debug('An error has occurred when syncing your order with MYOB. Error message: ' . $e->getMessage());
							$note =            'An error has occurred when syncing your order with MYOB. Error message: ' . $e->getMessage();

						} else {
							Opmc_Logger::debug('An error has occurred when syncing your invoice with MYOB. Error message: ' . $e->getMessage());
							$note =            'An error has occurred when syncing your invoice with MYOB. Error message: ' . $e->getMessage();
						}
						$order->add_order_note($note);
						$this->send_text_mail_to_admin($order_id);
						
					} catch (Throwable $e) {

						$order = new WC_Order( $order_id );
						$note;
						if ('yes' == $this->create_order_instead_of_invoice) {
							Opmc_Logger::debug('An error has occurred when syncing your order with MYOB. Error message: ' . $e->getMessage());
							$note =            'An error has occurred when syncing your order with MYOB. Error message: ' . $e->getMessage();

						} else {
							Opmc_Logger::debug('An error has occurred when syncing your invoice with MYOB. Error message: ' . $e->getMessage());
							$note =            'An error has occurred when syncing your invoice with MYOB. Error message: ' . $e->getMessage();
						} 
						$order->add_order_note($note);
						$this->send_text_mail_to_admin($order_id);
						
					}

				} else {
					$this->create_order_note($order_id, 'Customer UID Not Found');
				}

			} catch (Opmc_Myob_Exception $e) {
				$this->create_order_note($order_id, $e->getMessage());
			} catch (Throwable $e) {
				$this->create_order_note($order_id, $e->getMessage());
			}
		}


		/**
		 * Creates a note for a WooCommerce order when an error occurs and updates the order to reflect the failure.
		 */ 
		public function create_order_note( $order_id, $error_msg) {

			$order = wc_get_order($order_id);
			$note = 'There was an error in this transaction : ' . $error_msg;
			$order->add_order_note($note);
			$order->update_status('failed');
			// fail the woocommerce order, add order note
			//$this->send_order_fail_mail_to_customer($order);
		}

		/*
		public function send_order_fail_mail_to_customer( $order ){

			$wc_emails = WC()->mailer()->get_emails(); // Get all WC_emails objects instances
			$customer_email = $order->get_billing_email(); // The customer email
			if (isset($wc_emails['WC_Email_Failed_Order'])) {
				$wc_emails['WC_Email_Failed_Order']->recipient = $customer_email;
				// Sending the email from this instance
				$wc_emails['WC_Email_Failed_Order']->trigger( $order_id );
			}
		}*/

		public function send_text_mail_to_admin( $order_id) {
			$admin_email = get_option('admin_email');
			wp_mail($admin_email, 'Invoice Creating Failed for Order : ' . $order_id , 'Unable to Create Invoice in MYOB for Order : ' . $order_id );

		}
		

		public function change_order_status( $order_id, $old_status, $new_status, $order ) {
			Opmc_Logger::debug('changed status ');
			if ( 'failed' == $old_status && 'on-hold' == $new_status ) {
				$order->update_status('failed');
			}
		}


		public function receive_payment( $order_id) {
			Opmc_Logger::debug("mark_order_paid for $order_id");

			// apply payment to account specified by merchant

		}



		/**
		* Update the WooCommerce stock levels and pricing based on the data in MYOB.
		*
		* The product SKU is used as the primary reference however, when an item is sold the
		* UID is used as the reference.   This allows a SKU to remain the same but to point
		* to a new/updated product in MYOB.
		*
		* @param $skus - The list of skus to udpate, or update all skus if null
		*/
		public function sync_inventory_data( $skus = null) {
			Opmc_Logger::debug('get_myob_product_data');
						Opmc_Logger::debug('Testing WC_MYOB_cron_interval_sync'); 
			// get all products from MYOB
			$myob_inventory = $this->get_erp_inventory_items($skus);

			$args = array( 'post_type' => 'product', 'posts_per_page' => -1 );

			// get all the products from Woo
			$loop = new WP_Query( $args );
			if ( $loop->have_posts() ) {

				while ( $loop->have_posts() ) {

					$loop->the_post();

					//$itemUID = get_post_meta(get_the_ID(),'item_uid',true);
					$product = wc_get_product();
					Opmc_Logger::debug('Sku =>' . $product->get_sku());

					$sku = $product->get_sku();
					// find in MYOB array based on the SKU
					$item = $this->get_myob_item_from_sku($sku, $myob_inventory);

					if ( null != $item ) {
						Opmc_Logger::debug($item);

						// update the UID in Woo if not set - note we do not use UID
						// to identify the product in most scenarios, instead we use the SKU.
						$item_uid = get_post_meta(get_the_ID(), '_item_myob_uid', true);

						if ( '' === $item_uid ) {
							update_post_meta( get_the_ID(), '_item_myob_uid', $item->UID );
							update_post_meta( get_the_ID(), '_item_myob_last_sync', time());
						}

						// Set QuantityAvailable in Woo
						//$qty = $item->QuantityAvailable;
						$woocommerce_MYOB_integrations_settings =  get_option('woocommerce_MYOB_integrations_settings');
						$WC_MYOB_sync_type_inventory = $woocommerce_MYOB_integrations_settings['WC_MYOB_sync_type_inventory'];
						Opmc_Logger::debug('sync_type_inventory => ' . $WC_MYOB_sync_type_inventory);

						if ( !empty($WC_MYOB_sync_type_inventory ) && 'available' == $WC_MYOB_sync_type_inventory ) {

							$qty = (int) $item->QuantityAvailable;
							Opmc_Logger::debug('QuantityAvailable => ' . $qty);

						} else {

							$qty = (int) $item->QuantityOnHand;
							Opmc_Logger::debug('QuantityOnHand =>' . $qty);
						} //end
												
						Opmc_Logger::debug('Sku ' . $sku . 'Qty ' . $qty); 

						$product->set_stock_quantity($qty);					
												
						update_post_meta( $product->get_id(), 'is_synced', 'synced' );
						$product->save();
					} else {
						delete_post_meta( $product->get_id(), 'is_synced', 'synced' );
						Opmc_Logger::debug( 'SKU ' . $sku . ' not found in MYOB' );
					}
					// TODO
					// Set BaseSellingPrice
					// Set IncomeAccount etc
					// Set SellingDetails->TaxCode
				}
			}
		}

		/*
		* cron_schedules
		* check and execute cron job
		*/
		public function cron_schedule_paypal_email() {
			if ( !wp_next_scheduled( 'WC_MYOB_access_cron' ) ) {
				wp_schedule_event(time(), 'WC_MYOB_further_attempt', 'WC_MYOB_access_cron');
				$this->log->debug('cron_schedule_paypal_email');
			}
		}

		/*
		* cron_schedules
		* set interval for function to execute as cron job
		*/
		public function MYOB_cron_schedule( $schedules ) {

			if (!isset($schedules['WC_MYOB_further_attempt'])) {
				$this->log->debug('cron_schedule');
				$schedules['WC_MYOB_further_attempt'] = array(
					'interval'  => 300,
					'display'   => __( 'MYOB Sync', 'textdomain' )
				);
			}

			return $schedules;
		}

		public function MYOB_keep_alive_transient() {
			  Opmc_logger::debug('Keep Alive Transient is running.....');
			  //First time running transient
			if (false == get_transient('MYOB_keep_alive_transient') && false == get_transient('MYOB_keep_alive_run')) {
				Opmc_logger::debug('transient has been set and should run');
				set_transient('MYOB_keep_alive_transient', 'active', 600);
				set_transient('MYOB_keep_alive_run', 1, 600);

				$connector = new Opmc_Myob_Connector();

				if ( $connector ) {
					  $connector->refresh_token();
				}
			}

			  // Wait transient to be expired then run again
			if ( 'active' == get_transient('MYOB_keep_alive_transient') && 1 == get_transient('MYOB_keep_alive_run')) {
				  Opmc_logger::debug('Dont run transient, wait to be expired then run again');
			}
		}

		public function do_insert_product_in_myob( $post_id ) {
			// if ('no' == $this->enable_product_create) {
			// 	return false;
			// } PLUGINS-635

			$post_status = get_post_status( $post_id );

			if ('auto-draft' == $post_status) {
				return;
			}
			/* Autosave, do nothing */
			if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
				return;
			}
			/* Check user permissions */
			if (!current_user_can('edit_post', $post_id)) {
				return;
			}
			if ('product' == get_post_type( $post_id )) {
				$update = get_post_meta( $post_id, '_odoo_id', true );
				if ($update) {
					$this->sync_to_myob($post_id , (int) $update);
				} else {
					$this->sync_to_myob($post_id);
				}
			}
			return;
		}

		public function sync_to_myob( $post_id, $odoo_product_id = 0 ) {
			Opmc_Logger::debug("Call to sync_to_myob() in Opmc_Myob_Connector with arguments: $post_id $odoo_product_id");

			if ('no' == $this->enable_product_create) {
				return false;
			}

			$product = wc_get_product( $post_id );

			// if ( !$product ) {
			// 	return false;
			// } PLUGINS-635

			if ($product->get_sku() == '') {
					$error_msg = 'Error for product with id =>' . $product->get_id() . ' Error message : Invalid SKU - syncing blocked';
					return false;
			}
			$name = $product->get_name();
			$sku = $product->get_sku();
			$price = $product->get_price();
			$qty = $product->get_stock_quantity();


			$myob_product = array( 'Number' => $sku,
							'Name' => $name,
							'IsActive' => 'true',
							'IsSold' => 'true',
							'IncomeAccount' => array( 'UID' => $this->income_account),
							'SellingDetails' => array(
								'BaseSellingPrice' => $price,
								'SellingUnitOfMeasure'=> null,
								'ItemsPerSellingUnit'=> null,
								'IsTaxInclusive'=> true,
								'CalculateSalesTaxOn'=> 'ActualSellingPrice',
								'TaxCode' => array(
									'UID' => $this->tax_code_new_product
								)
							),
						);
			/* if stock is selected to be managed in Woo, the item will be created as
			* inventoried in MYOB.    Note that you cannot convert a non-inventoried item
			* to inventories in MYOB once it has been created.
			*/
			if ( $product->managing_stock() ) {

				if ( empty( $this->cogs_account ) || empty( $this->asset_account ) ) {
					Opmc_Logger::error( 'Cost of Sales and Asset Accounts must be set for inventoried product' );
				}

				$myob_product[ 'IsInventoried' ] = 'true';

				$myob_product[ 'CostOfSalesAccount' ] = array( 'UID' => $this->cogs_account );

				$myob_product[ 'AssetAccount' ] = array( 'UID' => $this->asset_account );

				if ( $qty < 1 ) {
					$qty = 1;
				}
				$myob_product[ 'QuantityOnHand' ] = $qty;
				$myob_product[ 'QuantityAvailable' ] = $qty;
			}

			Opmc_Logger::debug( $myob_product );

			$res = $this->remote_post_json( '/Inventory/Item?returnBody=true', $myob_product );
			Opmc_Logger::debug('test res');
			Opmc_Logger::debug($res);
			if ( null != $res ) {
				update_post_meta( $post_id, '_myob_number', $res->Number);
				update_post_meta( $post_id, '_myob_uid', $res->UID);
				update_post_meta( $post_id, '_myob_row_version', $res->RowVersion);
			}


			$item = $this->get_erp_inventory_items( $sku );

			$product_uid = $item[0]->UID;

			/*
			*  Adjust inventory
			*/
			if ( $product->managing_stock() ) {
				$query = array (
					'Date' => gmdate('Y-m-d') . 'T' . gmdate('H:i:s'),
					'Memo' => 'Created by WooCommerce',
					'Lines' => array (
						array (
							'Quantity' => $qty,
							'Item' => array (
								'UID' => $product_uid,
							),
							'Account' => array (
								'UID' => $this->asset_account,
							),
						),
					),
				);

				Opmc_Logger::debug( $query );


				$res = $this->remote_post_json( '/Inventory/Adjustment', $query );

			}
		}

		public function create_customer_payment( $order_id, $invoice) {

			Opmc_Logger::debug('===============================================================');
			Opmc_Logger::debug('Creating customer payment...');
			Opmc_Logger::debug('===============================================================');

			$query = array(
				'PayFrom' => 'Account',
				'Account' => array(
					'UID' => $this->asset_account
				),
				'Customer' => array(
					'UID' => $invoice->Customer->UID
				),
				'PayeeAddress' => 'My Tabs Pty Ltd',
				'StatementParticulars' => '',
				'PaymentNumber' => $invoice->Number,
				'Date' => $invoice->Date,
				'AmountPaid' => $invoice->BalanceDueAmount,
				'Memo' => 'Payment; My Tabs Pty Ltd',
				'Invoices' => array(
					array(
						'UID' => $invoice->UID,
						'AmountApplied' => $invoice->BalanceDueAmount,
						'Type' => 'Invoice'
					)
				),
				'DeliveryStatus' => 'Print',
				'ForeignCurrency' => null

			);
			Opmc_Logger::debug( $query );
			$this->remote_post_json( '/Sale/CustomerPayment/', $query );
		}

		public function fetch_invoice( $order_id, $invoice_date) {
			$wc_settings =  get_option('woocommerce_MYOB_integrations_settings');
			$enable_myob_invoice_number = $wc_settings['WC_OPMC_enable_myob_invoice_number'];

			if ('yes' == $enable_myob_invoice_number) {

				$filter = 'CustomerPurchaseOrderNumber eq ' . "'" . $order_id . "'";
			} else {
				$invoice_number = $this->invoice_id_prefix . $order_id;
				$filter = 'Number eq ' . "'" . $invoice_number . "'";
			}

			$params = array( '$filter' => urlencode($filter) );
			$invoice_type_meta = get_post_meta( $order_id, 'invoice_type', true);
			if (!empty($invoice_type_meta)) {

				if ('items' == $invoice_type_meta) {

					$invoice = $this->remote_get_json( $this->full_endpoint . '/Sale/Invoice/Item', $params);

				} elseif ('professional' == $invoice_type_meta) {

					$invoice = $this->remote_get_json( $this->full_endpoint . '/Sale/Invoice/Professional', $params);

				} else {

					$invoice = $this->remote_get_json( $this->full_endpoint . '/Sale/Invoice/Service', $params);
				}
			} else {
				
				$invoice = $this->remote_get_json( $this->full_endpoint . '/Sale/Invoice/Item', $params);
			}


			Opmc_Logger::debug('=========================================================================================================');
			Opmc_Logger::debug('GET REQUEST RESPONSE BODY (MYOB Invoice)');
			Opmc_Logger::debug(print_r($invoice, true));
			Opmc_Logger::debug('=========================================================================================================');


			$invoice_item = null;


			Opmc_Logger::debug('================================================================');
			Opmc_Logger::debug('Checking GET response invoice items...');

			// Extract invoice with date matching $invoice_date when retrieving multiple invoices with the same number.
			foreach ($invoice->Items as $item) {
				Opmc_Logger::debug('Required Date: ' . $invoice_date . ': Item Date: ' . $item->Date);
				if ($invoice_date == $item->Date) {
					$invoice_item = $item;
					Opmc_Logger::debug('MATCHING INVOICE ITEM FOUND!');
				} 
			}
			Opmc_Logger::debug('Finished checking GET response invoice items');
			Opmc_Logger::debug('================================================================');


			if ( false !== $invoice && null !== $invoice && isset($invoice->Items) && count($invoice->Items) > 0) {
				$invoice_uid = $invoice_item->UID;

				Opmc_Logger::debug('Customer ' . $invoice_uid . ' found.');
				$res = $invoice_item;
				return $res;
			}
			return null;
		}


		public function import_product_to_myob() {
			global $wpdb;
			$posts = $wpdb->get_results("SELECT   wp_posts.ID FROM wp_posts  LEFT JOIN wp_postmeta ON (wp_posts.ID = wp_postmeta.post_id AND wp_postmeta.meta_key = '_myob_uid' ) WHERE 1=1  AND ( 
				wp_postmeta.post_id IS NULL
			) AND wp_posts.post_type = 'product' AND (wp_posts.post_status = 'publish' OR wp_posts.post_status = 'future' OR wp_posts.post_status = 'draft' OR wp_posts.post_status = 'pending' OR wp_posts.post_status = 'private') GROUP BY wp_posts.ID ORDER BY wp_posts.post_date DESC", 'ARRAY_A');
			$this->import_product_to_myob_process->empty_data();
			update_option('woo_product_synced_to_myob_count', 0 );

			foreach ($posts as $post) {
				// print_r($post);exit;
				$this->import_product_to_myob_process->push_to_queue( $post['ID'] );
			}
			update_option('myob_woo_product_count', count($posts));
			// print_r($this->import_product_to_myob_process);exit;
			$this->import_product_to_myob_process->save()->dispatch();
		}



		public function search_product_item( $product_id ) {
			$sku = get_post_meta($product_id , '_sku', true);
			$product = $this->get_erp_inventory_items($sku);
			if (empty($product)) {
				return false;
			} else {
				update_post_meta( $product_id, '_myob_number', $product[0]->Number);
				update_post_meta( $product_id, '_myob_uid', $product[0]->UID);
				update_post_meta( $product_id, '_myob_row_version', $product[0]->RowVersion);
				return true;
			}
		} 


		/**
		 * Determines the form of the endpoint used in the API call to MYOB when retrieving MYOB products for synchronisation with WooCommerce.
		 */ 
		public function sync_products_from_myob() {

			Opmc_Logger::debug('Call to sync_products_from_myob() in Opmc_Myob_Connector');

			$config = get_option( 'woocommerce_MYOB_integrations_settings');
			// $limit = $config['WC_OPMC_create_product_to_woo_list_limit']; Reserved for future work in PLUGINS-1284
			$limit = 1000;
			$next_url = get_option('myob_product_pull_next_url');
			if ( null != $next_url ) {
				$url = $next_url;
			} else {
				update_option('myob_product_synced_count', 0 );
				$url = $this->full_endpoint . '/Inventory/Item?$top=' . $limit;
			}

			$this->fetch_product_api($url);
		}



		/**
		 * Retrieves a batch of products from MYOB to be synchronised with the WooCommerce product catalogue.
		 *
		 * @param  str $url [Url to fetch the product from myob]
		 */
		public function fetch_product_api( $url ) {

			Opmc_Logger::debug("Call to fetch_product_api() in Opmc_Myob_Connector with arguments: $url");

			$products = $this->remote_get_json( $url );
			$local_data = file_get_contents( WC_MYOB_INTEGRATION_PLUGINURL . 'assets/json/products.json' );
			$local_files = json_decode( $local_data, true );

			foreach ( $products->Items as $key => $item) {
				$this->product_import_process->push_to_queue( $item->UID );
				$local_files[ $item->UID ] = $item;
			}

			file_put_contents( WC_MYOB_INTEGRATION_PLUGINDIR . 'assets/json/products.json', json_encode( $local_files ) );
			$this->product_import_process->save()->dispatch();

			update_option('myob_product_pull_next_url', $products->NextPageLink);
			update_option('myob_product_count', count($local_files));
		}


		/**
		 * Retrieves image information for an MYOB product's photo, which is used when synchronising products from MYOB to WooCommerce.
		 */ 
		public function get_product_image_info( $item_UID) {

			Opmc_Logger::debug("Call to get_product_image_info() in Opmc_Myob_Connector with arguments: $item_UID");

			return $this->remote_get_json($this->full_endpoint . '/Inventory/Item/' . $item_UID . '/Photo');
		}
	}
endif;
