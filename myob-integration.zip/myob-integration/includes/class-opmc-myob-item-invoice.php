<?php

/**
* Implements a class that represents a MYOB Invoice made up of physical Items
*/
class Opmc_Myob_Item_Invoice {
	
	public $status;
		
	public function __construct( $order, $order_id, $customer_uid, $freight_tax_code, $myob_items, $tax_inclusive = true) {
		$this->line_items = null;
		$this->address = '';
		$this->order = $order;
		$this->order_id = $order_id;
		$this->customer_uid = $customer_uid;
		$this->freight_tax_code = $freight_tax_code;
		$this->tax_inclusive = true;
		$this->myob_items = $myob_items;
	}


	private function get_myob_uid_from_sku( $sku) {
		foreach ( $this->myob_items as $x ) {
			if ( $x->Number == $sku ) {
				return $x->UID;
			}
		}
	}


	public function add_line_item( $item_id, $item_data, $tax_code) {
		$product = $item_data->get_product();
		$sku = $product->get_sku();

		$wc_settings =  get_option('woocommerce_MYOB_integrations_settings'); 
		$WC_MYOB_customer_id_prefix = $wc_settings['WC_MYOB_job_code'];

		$item_meta = $item_data->get_meta();


		if ($product->get_meta('_myob_product_job_code', true)) {
			$job = array(
					'UID' => $product->get_meta('_myob_product_job_code', true),
				);
		} else if (isset($wc_settings['WC_MYOB_job_code']) && !empty($wc_settings['WC_MYOB_job_code'])) {
			$job = array(
					'UID' => $wc_settings['WC_MYOB_job_code'],
				);
		} else {
			$job = null;
		}

		// Opmc_Logger::debug( ' Subtotal ' . $item_data->get_subtotal() );
		// Opmc_Logger::debug( ' Total ' . $item_data->get_total() );
		// Opmc_Logger::debug( ' Qty ' . $item_data->get_quantity() );


		$unit_price = ( $item_data->get_subtotal()+$item_data->get_total_tax() ) / $item_data->get_quantity();

		$line_item = array(
				'Type' => 'Transaction',
				'Description' => $item_data->get_name(),
				'ShipQuantity' => $item_data->get_quantity(),
				'UnitPrice' => number_format((float) $unit_price, 2, '.', ''),
				'DiscountPercent' => 0,
				'TaxCode' => array(
					'UID' => $tax_code
				),
				'Item' => array(
					'UID' => $this->get_myob_uid_from_sku($sku),
				),
				'Job' => $job,
			);

		$this->line_items[] = $line_item;

		// Coupons used in the order LOOP (as they can be multiple)
		$coupon_name = array();
		if (!empty($this->order->get_coupon_codes())) {

			foreach ( $this->order->get_coupon_codes() as $coupon_code ) {
				$coupon_post_obj = get_page_by_title($coupon_code, OBJECT, 'shop_coupon');
				$coupon_id       = $coupon_post_obj->ID;
				$coupon = new WC_Coupon($coupon_id);
				 $get_description = $coupon->get_description();

				if (!empty($get_description)) {

					$coupon_name[] = $get_description;
				} else {
					$coupon_name[] = $coupon_code;
				}
			}

			$str = implode(', ', $coupon_name); 
			$order_ids = $this->order->get_id();
			$discount_line_created = get_post_meta($order_ids, 'coupon_check', true);

			if ('discount_line_created' != $discount_line_created) {
		
				$line_items = array(
					'Type' => 'Transaction',
					'Description' => 'Discount (' . $str . ')',
					'ShipQuantity' => -1,
					'UnitPrice' => number_format((float) $this->order->get_total_discount(), 2, '.', ''),
					'DiscountPercent' => 0,
					'TaxCode' => array(
						'UID' => $tax_code
					),
					'Item' => array(
						'UID' => $this->get_myob_uid_from_sku($sku),
					),
					'Job' => $job,
				);

				$this->line_items[] = $line_items;
				update_post_meta($order_ids, 'coupon_check', 'discount_line_created');
			}
		} // End
	}

	public function add_line_service( $item_id, $item_data, $tax_code) {
		
		$product = $item_data->get_product();
		$sku = $product->get_sku();
		$wc_settings =  get_option('woocommerce_MYOB_integrations_settings'); 
		$WC_MYOB_customer_id_prefix = $wc_settings['WC_MYOB_job_code'];

		$item_meta = $item_data->get_meta();

		if ($product->get_meta('_myob_product_job_code', true)) {
			$job = array(
					'UID' => $product->get_meta('_myob_product_job_code', true),
				);
		} else if (isset($wc_settings['WC_MYOB_job_code']) && !empty($wc_settings['WC_MYOB_job_code'])) {
			$job = array(
					'UID' => $wc_settings['WC_MYOB_job_code'],
				);
		} else {
			$job = null;
		}

		/** My Custom code for Create service invoice */
		$dollar_format = function( $x) {
			return number_format((float) $x, 2, '.', '');
		};
		$unit_price = ( $item_data->get_subtotal()+$item_data->get_total_tax() ) / $item_data->get_quantity();
		$income_account = $wc_settings['WC_MYOB_income_account'];
		$line_item = array(
				'Type' => 'Transaction',
				'Description' => $item_data->get_name(),
				'UnitOfMeasure' => null,
				'UnitCount' => $item_data->get_quantity(),
				'UnitPrice' => number_format((float) $unit_price, 2, '.', ''),
				'DiscountPercent' => 0,
				'Total' => $dollar_format($unit_price*$item_data->get_quantity()),
				'Account' => array(
					'UID' => $income_account,
				),
				'Job' => $job,
				'TaxCode' => array(
					'UID' => $tax_code,
				)
			);
		/*End*/
		$this->line_items[] = $line_item;

		// Coupons used in the order LOOP (as they can be multiple)
		$order_ids = $this->order->get_id();
		$coupon_check = get_post_meta($order_ids, 'coupon_check', true);


		$coupon_name = array();

		if (!empty($this->order->get_coupon_codes())) {

			foreach ( $this->order->get_coupon_codes() as $coupon_code ) {
				$coupon_post_obj = get_page_by_title($coupon_code, OBJECT, 'shop_coupon');
				$coupon_id       = $coupon_post_obj->ID;
				$coupon = new WC_Coupon($coupon_id);
				 $get_description = $coupon->get_description();

				if (!empty($get_description)) {

					$coupon_name[] = $get_description;
				} else {
					$coupon_name[] = $coupon_code;
				}
			}

			$str = implode(', ', $coupon_name);

			$order_ids = $this->order->get_id();
			$discount_line_created = get_post_meta($order_ids, 'coupon_check', true);

			if ('discount_line_created' != $discount_line_created) {
				$line_items = array(
					'Type' => 'Transaction',
					'Description' => 'Discount (' . $str . ')',
					'UnitOfMeasure' => null,
					'UnitCount' => -1,
					'UnitPrice' => number_format((float) $this->order->get_total_discount(), 2, '.', ''),
					'DiscountPercent' => 0,
					'Total' => -number_format((float) $this->order->get_total_discount(), 2, '.', ''),
					'Account' => array(
					'UID' => $income_account,
				),
					'TaxCode' => array(
						'UID' => $tax_code
					),
					'Job' => $job,
				);

				$this->line_items[] = $line_items;
				update_post_meta($order_ids, 'coupon_check', 'discount_line_created');
			}
		} // End
	}

	public function add_line_professional( $item_id, $item_data, $tax_code) {
		
		$product = $item_data->get_product();
		$sku = $product->get_sku();

		$wc_settings =  get_option('woocommerce_MYOB_integrations_settings'); 
		$WC_MYOB_customer_id_prefix = $wc_settings['WC_MYOB_job_code'];

		$item_meta = $item_data->get_meta();

		if ($product->get_meta('_myob_product_job_code', true)) {
			$job = array(
					'UID' => $product->get_meta('_myob_product_job_code', true),
				);
		} else if (isset($wc_settings['WC_MYOB_job_code']) && !empty($wc_settings['WC_MYOB_job_code'])) {
			$job = array(
					'UID' => $wc_settings['WC_MYOB_job_code'],
				);
		} else {
			$job = null;
		}

		// Get local time and date
		$wp_dt = gmdate('Y-m-d') . 'T' . gmdate('H:i:s');
		$date_format = 'Y-m-d'; 
		$time_format = 'H:i:s';
		$localdt = get_date_from_gmt($wp_dt, $date_format);
		$localtm = get_date_from_gmt($wp_dt, $time_format);
		

		/** My Custom code for Create professional invoice */
		$dollar_format = function( $x) {
			return number_format((float) $x, 2, '.', '');
		};
		$unit_price = ( $item_data->get_subtotal()+$item_data->get_total_tax() ) / $item_data->get_quantity();
		$income_account = $wc_settings['WC_MYOB_income_account'];
		$line_item = array(
				'Type' => 'Transaction',
				'Description' => $item_data->get_name(),
				'Date' => $localdt . 'T' . $localtm,
				'UnitOfMeasure' => null,
				'UnitCount' => $item_data->get_quantity(),
				'UnitPrice' => number_format((float) $unit_price, 2, '.', ''),
				'DiscountPercent' => 0,
				'Total' => $dollar_format($unit_price*$item_data->get_quantity()),
				'Account' => array(
					'UID' => $income_account,
				),
				'Job' => $job,
				'TaxCode' => array(
					'UID' => $tax_code,
				)
			);
		/*End*/
		$this->line_items[] = $line_item;

		$shipping = $this->order->get_total_shipping()+ $this->order->get_shipping_tax();   

		if (isset($shipping) && 0 != $shipping) {
			
			$line_item = array(
				'Type' => 'Transaction',
				'Description' => 'Shipping Method (' . $this->order->get_shipping_method() . ')',
				'Date' => $localdt . 'T' . $localtm,
				'UnitOfMeasure' => null,
				'UnitCount' => 1,
				'UnitPrice' =>$dollar_format($this->order->get_total_shipping()+ $this->order->get_shipping_tax()),
				'DiscountPercent' => 0,
				'Total' => $dollar_format($this->order->get_total_shipping()+ $this->order->get_shipping_tax()),
				'Account' => array(
					'UID' => $income_account,
				),
				'Job' => $job,
				'TaxCode' => array(
					'UID' => $tax_code,
				)
			);
			/*End*/
			$this->line_items[] = $line_item;
		}

		// Coupons used in the order LOOP (as they can be multiple)
		$coupon_name = array();
		if (!empty($this->order->get_coupon_codes())) {

			foreach ( $this->order->get_coupon_codes() as $coupon_code ) {
				$coupon_post_obj = get_page_by_title($coupon_code, OBJECT, 'shop_coupon');
				$coupon_id       = $coupon_post_obj->ID;
				$coupon = new WC_Coupon($coupon_id);
				 $get_description = $coupon->get_description();

				if (!empty($get_description)) {

					$coupon_name[] = $get_description;
				} else {
					$coupon_name[] = $coupon_code;
				}
			}

			$str = implode(', ', $coupon_name);

			$order_ids = $this->order->get_id();
			$discount_line_created = get_post_meta($order_ids, 'coupon_check', true);

			if ('discount_line_created' != $discount_line_created) {

				$line_items = array(
					'Type' => 'Transaction',
					'Description' => 'Discount (' . $str . ')',
					'Date' => $localdt . 'T' . $localtm,
					'UnitOfMeasure' => null,
					'UnitCount' => -1,
					'UnitPrice' => number_format((float) $this->order->get_total_discount(), 2, '.', ''),
					'DiscountPercent' => 0,
					'Total' => -number_format((float) $this->order->get_total_discount(), 2, '.', ''),
					'Account' => array(
						'UID' => $income_account,
					),
					'TaxCode' => array(
						'UID' => $tax_code
					),
					'Item' => array(
						'UID' => $this->get_myob_uid_from_sku($sku),
					),
					'Job' => $job,
				);

				$this->line_items[] = $line_items;
				update_post_meta($order_ids, 'coupon_check', 'discount_line_created');
			}
		} // End
	}

	public function set_address() {

		if ('' == $this->order->get_address('shipping')['address_2']) {
			$S_streetaddress = '';
		} else {
			$S_streetaddress = $this->order->get_address('shipping')['address_2'];
		}

		if ('' == $this->order->get_address('billing')['address_2']) {
			$B_streetaddress = '';
		} else {
			$B_streetaddress = $this->order->get_address('shipping')['address_2'];
		}
		
		if ('' == $this->order->get_address('shipping')['address_1']) {

			$this->address = $this->order->get_billing_last_name() . ' ' . $this->order->get_billing_first_name() . ', ' . $this->order->get_address('billing')['address_1'] . $S_streetaddress . ', ' . $this->order->get_billing_city() . ', ' . $this->order->get_billing_state() . ', ' . $this->order->get_billing_postcode() . ', ' . $this->order->get_billing_country();

		} else {
			$this->address = $this->order->get_shipping_last_name() . ' ' . $this->order->get_shipping_first_name() . ', ' . $this->order->get_address('shipping')['address_1'] . $B_streetaddress . ', ' . $this->order->get_shipping_city() . ', ' . $this->order->get_shipping_state() . ', ' . $this->order->get_shipping_postcode() . ', ' . $this->order->get_shipping_country();
		}
	}

	public function generate_post_data() { 

		$dollar_format = function( $x) {
			return number_format((float) $x, 2, '.', '');
		};
		$woocommerce_MYOB_integrations_settings =  get_option('woocommerce_MYOB_integrations_settings'); 
		$WC_MYOB_customer_id_prefix = $woocommerce_MYOB_integrations_settings['WC_MYOB_invoice_id_prefix'];
		$myob_invoice_number_setting = $woocommerce_MYOB_integrations_settings['WC_OPMC_enable_myob_invoice_number'];

		if ('yes' == $myob_invoice_number_setting) {
			$invoice_number = null;
		} else {
			$invoice_number =  $WC_MYOB_customer_id_prefix . $this->order_id;
		}
		
		// Get local time and date
		$wp_dt = gmdate('Y-m-d') . 'T' . gmdate('H:i:s');
		$date_format = 'Y-m-d'; 
		$time_format = 'H:i:s';
		$localdt = get_date_from_gmt($wp_dt, $date_format);
		$localtm = get_date_from_gmt($wp_dt, $time_format);

		$res = array(
			'Number' => $invoice_number,
			'Date'   => $localdt . 'T' . $localtm,
			'CustomerPurchaseOrderNumber' => $this->order_id, 
			'Customer' => array(
				'UID' => $this->customer_uid
			),
			'ShipToAddress' => $this->address,
			'Terms' => array(
				'PaymentIsDue'  	=> 'PrePaid'
			),
			'IsTaxInclusive'	=> $this->tax_inclusive,
			'Lines' =>	$this->line_items,
			'Subtotal' =>  $dollar_format($this->order->get_subtotal()),
			'Freight' => $dollar_format($this->order->get_total_shipping()+ $this->order->get_shipping_tax()),
			// "Freight" => $dollar_format($this->order->get_total_shipping()),
			'FreightTaxCode' => array(
				'UID' => $this->freight_tax_code
			),
			'TotalTax' => $dollar_format($this->order->get_total_tax() + $this->order->get_shipping_tax()),
			'TotalAmount' => $dollar_format($this->order->get_total()),
			'Category' => null,
			'Comment' => '',
			'ShippingMethod' => null,
			'PromisedDate' => null,
			'JournalMemo' => 'WooCommerce Order ' . $this->order_id . ' from ' . $this->order->get_billing_last_name() . ', ' . $this->order->get_billing_first_name() . ', ' . $this->order->get_billing_email(),
			'BillDeliveryStatus' => 'Print',
			'AppliedToDate' => 0,
			'BalanceDueAmount' =>  0,
			'Status' => $this->status,
			'LastPaymentDate' => null,
			'Order' => null, 
			'ForeignCurrency' => null
		);
		return $res;

	}

}
