<?php
/**
 *  WooCommerce MYOB Integration.
 *
 * @package   WooCommerce MYOB Integration
 */

require_once( __DIR__ . '/opmc/class-opmc-logger.php' );
require_once( __DIR__ . '/class-opmc-myob-connector.php' );

if ( ! class_exists( 'WC_MYOB_Integrations_Settings' ) ) :
	class WC_MYOB_Integrations_Settings extends WC_Integration {
		/**
		 * Init and hook in the integration.
		*/
		private $client_id = '';
		private $connector = null;
		private $company_file_list = null;
		private $income_accounts_list = null;

		public function __construct() {
			Opmc_Logger::trace('Creating Settings Object');

			$this->id                 = 'myob_integrations';
			$this->method_title       = __( 'MYOB AccountRight', 'woocommerce-integration-demo' );
			$this->method_description = __( 'MYOB Integration' );
			// Load the settings.
			$this->init_settings();

			$config = get_option( 'woocommerce_MYOB_integrations_settings');

			// Define user set variables.
			$this->company_file_id    = $this->get_option( 'WC_MYOB_company_file_id' );

			$this->MYOB_tax_code_for_new_products = $this->get_option( 'WC_MYOB_tax_code_new_products' );
			$this->MYOB_freight_tax_code = $this->get_option( 'WC_MYOB_freight_tax_code' );
			$this->MYOB_income_account = $this->get_option( 'WC_MYOB_income_account' );

			$this->asset_account = $this->get_option( 'WC_MYOB_asset_account' );
			$this->cogs_account = $this->get_option( 'WC_MYOB_cogs_account' );


			$this->customer_id_prefix = $this->get_option('WC_MYOB_customer_id_prefix');
			$this->guest_customer_display_id = $this->get_option('WC_MYOB_guest_customer_display_id');
		
			// Actions.
			add_action( 'woocommerce_update_options_integration_' . $this->id, array( $this, 'process_admin_options' ) );
			// General.
			add_action( 'admin_notices', array( $this, 'admin_notices' ) );
			// Filters.
			add_filter( 'woocommerce_settings_api_sanitized_fields_' . $this->id, array( $this, 'sanitize_settings' ) );


			// Init Connector with reference to this object
			$this->connector = new Opmc_Myob_Connector($this);

			// any of the setting parameters that are retrieved via AJAX are stored
			// in transients in order to not overload the MYOB API

		
			$this->company_files = get_option( 'WC_MYOB_company_file_list' );
			$this->income_accounts = get_option( 'WC_MYOB_income_accounts_list' );
			$this->cogs_accounts = get_option( 'WC_MYOB_cogs_accounts_list' );
			//$this->expense_accounts = $this->transient('WC_MYOB_expense_accounts_list', array($this->connector, 'get_expense_accounts'));
			$this->asset_accounts = get_option( 'WC_MYOB_asset_accounts_list' );
		
			// TODO re-write to pull from local DB
			$this->tax_codes = get_option('WC_MYOB_tax_codes_list' );
			$this->job_codes = get_option('WC_MYOB_job_codes_list' );

			$this->init_form_fields();
		}

		/**
		* Wrapper for WP transients
		*/
		public function transient( $key, $func) {

			Opmc_Logger::trace("transient $key");
			$x = get_transient($key);
			if ( false === $x || !is_array($x) || ( isset($x[0]) && empty($x[0]) )) {
				$x = $func();
				if ( is_countable($x) && count($x) > 0) {
					Opmc_Logger::trace('getting from rest');
					set_transient($key, $x, 3600);
				}
			} else {
				Opmc_Logger::trace('getting from cache count is ' . count($x));
			}

			return $x;	
		}
	 
		/**
		 * Initialize integration settings form fields.
		 *
		 * @return void
		 */
		public function init_form_fields() {
			$invoice_type = array(
				'items' => 'Items',			
				'service' => 'Service', 
				'professional' => 'Professional'
			);

			$sync_type = array(
				'available' => 'Available',			
				'stockonhand' => 'Stock on Hand', 
			);

			$this->form_fields = array(
			'allow_access' => array(
				'title'             => __( 'Validate Access', 'WC-MYOB-setting-tab' ),
				'type'              => 'button',
				'custom_attributes' => array(
					'onclick' => "location.href='" . $this->assemble_myob_auth_url() . "'",
				),
				'description'       => __( 'Click the button to validate (or re-validate) your access from WooCommerce to MYOB.'),
				'desc'              => true,
			),
			 'WC_MYOB_company_file_username' => array(
				'title'             => __( 'Company File Username', 'WC-MYOB-setting-tab' ),
				'type'              => 'text',
				'description'       => __( 'Enter company file username, save changes, then click on the "Reload Accounts List" button.' ),
				'desc'          	=> true,
				'default'       	=> ''
			),
			  'WC_MYOB_company_file_password' => array(
				'title'             => __( 'Company File Password (optional)', 'WC-MYOB-setting-tab' ),
				'type'              => 'password',
				'description'       => __( 'Add company file password (optional)' ),
				'desc'          	=> true,
				'default'       	=> ''
			),    
			'reload_accounts_list' => array(
				'title'             => __( 'Reload Accounts List', 'WC-MYOB-setting-tab' ),
				'type'              => 'button',
				'custom_attributes' => array( 
					'onclick' => '',
				),
				'description'       => __( 'Click the button to reload the lists of valid accounts from MYOB.', 'WC-MYOB-setting-tab' ),
				'desc_tip'          => false,
			),
			'WC_MYOB_company_file_id' => array(
				'title'             => __( 'Company File', 'WC-MYOB-setting-tab' ),
				'type'              => 'select',
				'description'       => __( 'Set MYOB Company File ID.' ),
				'desc'         		=> true,
				'default'      		=> '',
				'options'			=> $this->company_files,
				'custom_attributes' => array(
					'class' => 'hide'
				)
			),
			'WC_MYOB_customer_id_prefix' => array(
				'title'             => __( 'Customer Display ID Prefix (optional)', 'WC-MYOB-setting-tab' ),
				'type'              => 'text',
				'description'       => __( 'This is prefixed to the customer display in MYOB when a new customer record is created by Woo.' ),
				'desc'              => true,
				'default'           => 'WOO-',
				'css'               => 'max-width:7em;',
			), 
			'WC_MYOB_guest_customer_display_id' => array(
				'title'             => __( 'Guest Customer Display ID', 'WC-MYOB-setting-tab' ),
				'type'              => 'text',
				'description'       => __( 'If set, all purchases from "guest" customers on WooCommerce will be assigned to this customer in MYOB.  If blank, each guest purchase will create a new customer record in MYOB.' ),
				'desc'              => true,
				'default'           => '',
				'css'               => 'max-width:12em;',
			),              
			'WC_MYOB_invoice_id_prefix' => array(
				'title'             => __( 'Invoice Display ID Prefix (required)', 'WC-MYOB-setting-tab' ),
				'type'              => 'text',
				'description'       => __( 'This string is prefixed to the invoice number in MYOB when a new invoice or order is created by Woo.' ),
				'desc'              => true,
				'default'           => 'WOO-',
				'css'               => 'max-width:7em;',
			),
			  'WC_MYOB_sync_period' => array(
				'title'             => __( 'Sync Period in Days', 'WC-MYOB-setting-tab' ),
				'type'              => 'number',
				'description'       => __( 'Set the number of days between MYOB synchronisations', 'WC-MYOB-setting-tab' ),
				'desc_tip'          => false,
				'default'           => 1,
				'css'               => 'max-width:7em;',
				'min'               => 1,
			),    
			'WC_MYOB_income_account' => array(
				'title'             => __( 'Income Account', 'WC-MYOB-setting-tab' ),
				'type'              => 'select',
				'description'       => __( 'Select the default income account to use for new products created by the plugin automatically in MYOB if they do not already exist.  This setting will be ignored for products already in MYOB and instead the chosen income account in MYOB will be used.' ),
				'desc'          	=> true,
				'default'           => '',
				'options'			=> $this->income_accounts,
			),
			'WC_MYOB_invoice_type' => array(
				'title'             => __( 'Default MYOB Invoice Type', 'WC-MYOB-setting-tab' ),
				'type'              => 'select',
				'description'       => __( 'If there is a combination of MYOB product types within an order (Items, Service, Professional), then a MYOB invoice of this type will be created.' ),
				'desc'          => false,
				'default'           => 'items',
				'options'			=> $invoice_type,
			),
			'WC_MYOB_cogs_account'  => array(
				'title'             => __( 'Cost Of Sales Account', 'WC-MYOB-setting-tab' ),
				'type'              => 'select',
				'description'       => __( 'Select the default income account to use for new products created by the plugin automatically if they do not exist in MYOB already.   Cost of sales account is only used for "inventoried" items.' ),
				'desc'              => true,
				'default'           => '',
				'options'           =>$this->cogs_accounts,
			),
			'WC_MYOB_asset_account' => array(
				'title'             => __( 'Asset Account', 'WC-MYOB-setting-tab' ),
				'type'              => 'select',
				'description'       => __( 'Select the default asset account to use for new products created by the plugin automatically if they do not exist in MYOB already.  Asset account is only used for "inventoried" items. Please ensure that the account selected is registered as a bank account in MYOB.' ),
				'desc'          	=> true,
				'default'       	=> '',
				'options'           => $this->asset_accounts,
			),
			


			'WC_MYOB_tax_code_new_products' => array(
				'title'             => __( 'Default Tax Code for New Products', 'WC-MYOB-setting-tab' ),
				'type'              => 'select',
				'description'       => __( 'Select the default tax code to use for new products created by the plugin automatically in MYOB if they do not exist.  This setting will be ignored for products already in MYOB and instead the chosen income account in MYOB will be used.' ),
				'desc'      	    => true,
				'default' 	     	=> '',
				'options'			=> $this->tax_codes,
			),
			

			'WC_MYOB_tax_code_line_items' => array(
				'title'             => __( 'Default Tax Code for Line Items', 'WC-MYOB-setting-tab' ),
				'type'              => 'select',
				'description'       => __( 'Select the default MYOB tax code to use for line items with an unrecognized tax code. If a line item appears with an unrecognised tax code, then the one selected here will be used for that item.' ),
				'desc'      	    => true,
				'default' 	     	=> '',
				'options'			=> $this->tax_codes,
			),



			'WC_MYOB_freight_tax_code' => array(
				'title'             => __( 'Freight Tax Code', 'WC-MYOB-setting-tab' ),
				'type'              => 'select',
				'description'       => __( 'Select the default tax code for freight charges.   This setting will be used independent of any settings in MYOB.' ),
				'desc'          	=> true,
				'default'       	=> '',
				'options'			=> $this->tax_codes,
			),
			'WC_MYOB_job_code' => array(
				'title'             => __( 'Job Code', 'WC-MYOB-setting-tab' ),
				'type'              => 'select',
				'description'       => __( 'Select the default job code.' ),
				'desc'          	=> true,
				'default'       	=> '',
				'options'			=> $this->job_codes,
			),
			'WC_MYOB_sync_type_inventory' => array(
				'title'             => __( 'Sync Product Inventory Type', 'WC-MYOB-setting-tab' ),
				'type'              => 'select',
				'description'       => __( 'Sync Woo Stock To Either MYOB "Available" or "Stock on Hand".' ),
				'desc'          => true,
				'default'           => 'available',
				'options'			=> $sync_type,
			),
			'allow_sync' => array(
				'title'             => __( 'Sync Product Inventory Levels', 'WC-MYOB-setting-tab' ),
				'type'              => 'button',
				'custom_attributes' => array(
					'onclick' => '',
				),
				'description'       => __( 'Click the button to manually sync inventory levels from MYOB to WooCommerce.', 'WC-MYOB-setting-tab' ),
				'desc_tip'          => false,
			),


			'WC_OPMC_create_product_to_woo_cron' => array(
				'title'             => __( 'Automatically copy products from MYOB to WooCommerce', 'WC-MYOB-setting-tab' ),
				'type'              => 'checkbox',
				'description'       => __( 'Automatically copy products from MYOB to WooCommerce' ),
				'desc'              => true,
				'default'           => 'no',
			),
			// 'WC_OPMC_create_product_to_woo_list_limit' => array(
			// 	'title'             => __( 'Number Of Records Fetch Product Per Request', 'WC-MYOB-setting-tab' ),
			// 	'type'              => 'number',
			// 	'description'       => __( 'Set Number Of Records Fetch Product Per Request.', 'WC-MYOB-setting-tab' ),
			// 	'desc_tip'          => false,
			// 	'default'           => 25,
			// 	'css'               => 'max-width:7em;',
			// ),                                                           Reserved for future work in PLUGINS-1284
			'WC_OPMC_create_product_to_woo_cron_frequency'   => array(
				'title'       => __( 'Cron Frequency For Product', 'WC-MYOB-setting-tab' ),
				'type'        => 'select',
				'label'       => 'Cron Frequency For Product',
				'default'     => '',
				'options'     => array(
					'hourly' => 'Every Hour',
					'twicedaily' => 'Twice A Day',
					'daily' => 'Once A Day',
				),
						'description' => 'Select cron frequency to sync products'
			),


			// 'export_product_to_myob' => array(
			// 	'title'				 => __( 'Export All Products to MYOB', 'WC-MYOB-setting-tab' ),
			// 	'type' 				 => 'button',
			// 	'custom_attributes'  => array(
			// 		'onclick' => '',
			// 	),
			// 	'description' 		 => __( 'Export all WooCommerce products to MYOB that are not already in AccountRight.', 'WC-MYOB-setting-tab' ),
			// 	'desc_tip' 			 => false,
			// ), PLUGINS-1285

			'WC_OPMC_enable_myob_invoice_number' => array(
				'title'             => __( 'Allow MYOB To Set The Invoice Number', 'WC-MYOB-setting-tab' ),
				'type'              => 'checkbox',
				'description'       => __( 'Allow MYOB to set the Invoice number, rather than passing the Woo Order number.' ),
				'desc'              => true,
				'default'           => 'no',
			),
			'WC_OPMC_enable_product_create' => array(
				'title'             => __( 'Create Product in MYOB if Not Found', 'WC-MYOB-setting-tab' ),
				'type'              => 'checkbox',
				'description'       => __( 'Create product in MYOB if not found.' ),
				'desc'              => true,
				'default'           => 'yes',
			),
			'WC_OPMC_create_guest_as_customer' => array(
				'title'             => __( 'Create Customer with Email for Guest ', 'WC-MYOB-setting-tab' ),
				'type'              => 'checkbox',
				'description'       => __( 'Creates a MYOB customer for guest users in WooCommerce based off their email. If the guest email is taken in MYOB, the customer UID is used instead.' ),
				'desc'              => true,
				'default'           => 'no',
			),
			'WC_OPMC_create_closed_invoices' => array(
				'title'				=> __( 'Create Closed Invoices', 'WC-MYOB-setting-tab' ),
				'type'				=> 'checkbox',
				'description'		=> __( 'If selected, invoices created by WooCommerce will be closed, otherwise they will remain open. Note: a bank account (in asset accounts) must be selected to create closed invoices. If orders are set to be created instead of invoices, this setting will be overridden regardless of selection.' ),
				'desc'				=> true,
				'default'			=> 'no',
			),
			'WC_OPMC_create_order_instead_of_invoice' => array(
				'title'             => __( 'Create Orders Instead of Invoices', 'WC-MYOB-setting-tab' ),
				'type'              => 'checkbox',
				'description'       => __( 'If selected, an MYOB order will be created instead of an MYOB invoice for WooCommerce purchases.' ),
				'desc'              => true,
				'default'           => 'no',
			),
			'WC_OPMC_create_orders_when_on_hold' => array(
				'title'             => __( 'Create Orders when On-Hold', 'WC-MYOB-setting-tab' ),
				'type'              => 'checkbox',
				'description'       => __( 'If selected, an MYOB order will be created when a WooCommerce order is on-hold.' ),
				'desc'              => true,
				'default'           => 'no',
			),
			'WC_OPMC_set_default_customer_designation' => array(
				'title'             => __( 'Set MYOB Default Customer Designation', 'WC-MYOB-setting-tab' ),
				'type'              => 'checkbox',
				'description'       => __( 'If not selected, the MYOB sets the Customer Designation to Company, if the customer fills out the Company field on Woo Checkout.' ),
				'desc'              => true,
				'default'           => 'yes',
			),
			'WC_OPMC_enable_debug_logging' => array(
				'title'             => __( 'Enable Debug Logging', 'WC-MYOB-setting-tab' ),
				'type'              => 'checkbox',
				'description'       => __( 'If enabled, detailed debugging logs will be created on your server.   Caution- these logs can quickly become very large and fill your server hard disk!' ),
				'desc'              => true,
				'default'           => 'no',
			),
			);
		}

		/**
		 * Generate Button HTML.
		 */
		public function generate_button_html( $key, $data ) {

			Opmc_Logger::debug('generate_button_html');

			$field    = $this->plugin_id . $this->id . '_' . $key;
			$defaults = array(
			'class'             => 'button-secondary',
			'css'               => '',
			'custom_attributes' => array(),
			'desc_tip'          => false,
			'description'       => '',
			'title'             => '',
			'disable'           => true,   
			);

			$allowed_html = array(
				'a' => array(
					'href' => array(),
					'title' => array()
				),
				'br' => array(),
				'em' => array(),
				'strong' => array(),
			);
			$data = wp_parse_args( $data, $defaults );
			ob_start();
			?>
		<tr valign="top">
			<th scope="row" class="titledesc">
				<label for="<?php echo esc_attr( $field ); ?>"><?php echo esc_html(wp_kses_post( $data['title'] )); ?></label>
				<?php echo esc_html($this->get_tooltip_html( $data )); ?>
			</th>
			<td class="forminp">
				<fieldset>
					<legend class="screen-reader-text"><span><?php echo esc_html(wp_kses_post( $data['title'] )); ?></span></legend>
					<button class="<?php echo esc_attr( $data['class'] ); ?>" type="button" name="<?php echo esc_attr( $field ); ?>" id="<?php echo esc_attr( $field ); ?>" style="<?php echo esc_attr( $data['css'] ); ?>" <?php echo wp_kses($this->get_custom_attribute_html( $data ), $allowed_html); ?> disabled="disabled"><?php echo wp_kses_post( $data['title'] ); ?></button>
					<?php echo wp_kses($this->get_description_html( $data ), $allowed_html); ?>
				</fieldset>
			</td>
		</tr>
			<?php
			return ob_get_clean();
		}

		/**
		 * Santize our settings
	 *
		 * @see process_admin_options()
		 */
		public function sanitize_settings( $settings ) {
			// We're just going to make the api key all upper case characters since that's how our imaginary API works
			if ( isset( $settings ) &&
			 isset( $settings['api_key'] ) ) {
				$settings['api_key'] = strtoupper( $settings['api_key'] );
			}
			return $settings;
		}


		/**
		 * Myob redirect uri.
		*/
		public function WC_MYOB_redirect_uri() {

			return WC_MYOB_INTEGRATION_PLUGINURL . 'MYOB-cronjob.php';
		}


		/**
		* Assembles the URL that will invoke the authentication process.   This starts by authenticating the user account against 
		* their MYOB instance.  The user will be redirected to our server once they have authorized access.
		*/
		public function assemble_myob_auth_url() {
			
			$redirect_uri = urlencode(WC_MYOB_API_REDIRECT_URL);
			$merchant_redirect_uri = urlencode($this->WC_MYOB_redirect_uri());

			$query = '?client_id=' . WC_MYOB_API_CLIENT_ID . '&redirect_uri=' . $redirect_uri .
			'&response_type=code&scope=CompanyFile' .
			'&state=' . $merchant_redirect_uri;
			
			return 'https://secure.myob.com/oauth2/account/authorize' . $query;

		}

		/**
		 * Generate a URL to our specific settings screen.
		 * 
		 * @since  1.3.4
		 * @return string Generated URL.
		 */
		public function get_settings_url () {
			return add_query_arg(
			array(
				'page'    => 'wc-settings',
				'tab'     => 'integration',
				'section' => 'myob_integrations',
			),
			admin_url( 'admin.php' )
			);
		}

		/**
		 * Displays notices in admin settings screen.
		 *
		 * @return string Error notices.
		 */
		public function admin_notices() {
			global $post;
			$config = get_option( 'woocommerce_MYOB_integrations_settings');

			/*
			 * TODO: this needs nonce verification.   Disabled for now.
			 *
			if ( isset( $_POST['save'] ) ) {
				if ( isset($_POST['_wp_http_referer']) && '/wp-admin/admin.php?page=wc-settings&tab=integration&section=myob_integrations' == $_POST['_wp_http_referer'] ) {
					if ( ( empty($config['WC_MYOB_tax_code']) || 0 == $config['WC_MYOB_tax_code'] ) || ( empty($config['WC_MYOB_freight_tax_code']) || 0 == $config['WC_MYOB_tax_code'] ) ) { 
						echo '<script>window.location.reload();</script>';
					}
				}
			}
			 */

			$screen = get_current_screen();
			$shop_page_url = get_permalink( get_option( 'woocommerce_shop_page_id' ) );
			$settings_id = 'woocommerce_myob_integrations';
			$url = $this->get_settings_url();
			
			if (empty( $this->company_file_id ) ) {
	
				echo '<div class="notice notice-warning"><p><strong>WooCommerce MYOB AccountRight is almost ready.</strong> To get started, <a href="' . esc_url( $url ) . '"> go to MYOB Account Settings </a> and click Validate Access to sign into MYOB.</p></div>' . "\n";

			} elseif (empty( $this->MYOB_tax_code_for_new_products ) || empty( $this->MYOB_freight_tax_code ) ) {

				echo '<div class="notice notice-warning"><p><strong>WooCommerce MYOB AccountRight is almost ready.</strong> To get started, <a href="' . esc_url( $url ) . '"> go to MYOB Account Settings </a> and select asset, income and tax accounts and click save button.</p></div>' . "\n";
			} 

			if ( get_option( 'WC_MYOB_api_unauthorized_count' ) > 0 ) {
				echo '<div class="notice notice-warning"><p><strong>WooCommerce MYOB is not authenticating with the MYOB server correctly.</strong></p>   Please ensure that you have entered your MYOB login credentials correctly, which includes your company file username. You may need to re-attempt authentication by clicking the Validate Access button. <br>Order information will not be sent to MYOB while authentication is failing. This message will stop appearing once a successful integration action with the MYOB server occurs (e.g. Reload Accounts List).</p></div>' . "\n";
			}
		}

	}

endif;

