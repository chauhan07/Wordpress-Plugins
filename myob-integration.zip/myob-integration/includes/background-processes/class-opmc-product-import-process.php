<?php

/**
 * Import Customer from MYOB to Woo in background process.
 */
class Opmc_Product_Import_Process extends WP_Background_Process {


	protected $action = 'cron_product_import_process';

	/**
	 * Import product to WooCommerce from MYOB
	 * 
	 * @param  [type] $item [description]
	 * @return [type]       [description]
	 */
	protected function task( $item ) {
		sleep( 1 );
		$local_data      = file_get_contents( WC_MYOB_INTEGRATION_PLUGINURL . 'assets/json/products.json' );
		$local_file_data = json_decode( $local_data, true );
		if ( isset( $local_file_data[ $item ] ) ) {
			$this->process_product_to_woo( $local_file_data[ $item ] );
			$synced_product = get_option('myob_product_synced_count');
			update_option('myob_product_synced_count', $synced_product + 1 );
		}
		return false;
	}


	/**
	 * Complete
	 *
	 * Override if applicable, but ensure that the below actions are
	 * performed, or, call parent::complete().
	 */
	protected function complete() {
		parent::complete();
		// Show notice to user or perform some other arbitrary task...
	}


	/**
	 * Process Product data to woocommerce
	 *
	 * @param  array $product_data Product details from MYOB
	 * @return bool  return status of the process
	 */
	public function process_product_to_woo( $product_data ) {
		if ( isset( $product_data['Number'] ) && ! empty( $product_data['Number'] ) ) {
			$product_id = get_post_id_by_meta_key_and_value('_sku', $product_data['Number']);

			if ( isset($product_id) && ( get_post_meta($product_id, '_myob_row_version' , true) ==  $product_data['RowVersion'] ) ) {
				return false;
			}
			$product_info = array(
				// 'post_author' => $TMWNI_OPTIONS['nsDefaultUser'],
				'post_content' => $product_data['Description'],
				'post_status' => ( 1 == $product_data['IsActive'] ) ? 'publish' : 'draft',
				'post_title' => $product_data['Name'],
				'post_parent' => 0,
				'post_type' => 'product',
				'post_excerpt' => $product_data['Name'],
			);

			if ( false == $product_id ) {
				$product_id = wp_insert_post( $product_info);
			} else {
				$product_info['ID'] = $product_id;
				$product_id = wp_update_post( $product_info);
			}

			wp_set_object_terms($product_id, 'simple', 'product_type');
			update_post_meta( $product_id, '_visibility', 'visible' );
			update_post_meta( $product_id, '_stock_status', 'instock');
			update_post_meta( $product_id, '_description', $product_data['Description']);
			update_post_meta( $product_id, '_sku', $product_data['Number']);
			update_post_meta( $product_id, '_product_attributes', array());
			update_post_meta( $product_id, '_regular_price', $product_data['BaseSellingPrice']);
			update_post_meta( $product_id, '_price', $product_data['BaseSellingPrice'] );

			if ( 1 == $product_data['IsInventoried'] ) {
				update_post_meta( $product_id, '_sold_individually', '' );
				update_post_meta( $product_id, '_manage_stock', 'yes' );
				$quantity = $product_data['QuantityOnHand']; 
				update_post_meta( $product_id, '_stock', $quantity);
				$stock_status = ( $quantity > 0 ) ? 'instock' : 'outofstock';
				update_post_meta( $product_id, '_stock_status', wc_clean( $stock_status ) );
				wp_set_post_terms( $product_id, $stock_status, 'product_visibility', true );
				update_post_meta( $product_id, '_saleunit', $product_data['SellingDetails']['ItemsPerSellingUnit']);
				update_post_meta( $product_id, '_stockunit', $product_data['SellingDetails']['SellingUnitOfMeasure']);
			}

			update_post_meta( $product_id, '_myob_number', $product_data['Number']);
			update_post_meta( $product_id, '_myob_uid', $product_data['UID']);
			update_post_meta( $product_id, '_myob_row_version', $product_data['RowVersion']);

			if ( null != $product_data['PhotoURI'] ) {
				$connection = new Opmc_Myob_Connector();
				$image_data = $connection->get_product_image_info($product_data['UID']);
				if ( isset( $image_data->Data ) && !empty( $image_data->Data ) ) {
					if ( get_post_meta( $product_id, '_myob_image_row_version', true ) != $image_data->RowVersion ) {
						$attach_id = $this->save_image( $image_data, $product_data['UID'] );
						set_post_thumbnail( $product_id, $attach_id );
						update_post_meta( $product_id, '_myob_image_row_version', $image_data->RowVersion);
					}
				}
			}
		}
	}

	public function save_image( $image_data, $title ) {

		$base64_img = $image_data->Data;
		$mime_type = $image_data->MimeType;
		// Upload dir.
		$upload_dir  = wp_upload_dir();
		$upload_path = str_replace( '/', DIRECTORY_SEPARATOR, $upload_dir['path'] ) . DIRECTORY_SEPARATOR;

		$img             = str_replace( ' ', '+', $base64_img );
		$decoded         = base64_decode( $img );
		$filename        = $title . mime2ext($mime2ext);
		$file_type       = $mime_type;
		$hashed_filename = md5( $filename . microtime() ) . '_' . $filename;

		// Save the image in the uploads directory.
		$upload_file = file_put_contents( $upload_path . $hashed_filename, $decoded );

		$attachment = array(
			'post_mime_type' => $file_type,
			'post_title'     => preg_replace( '/\.[^.]+$/', '', basename( $hashed_filename ) ),
			'post_content'   => '',
			'post_status'    => 'inherit',
			'guid'           => $upload_dir['url'] . '/' . basename( $hashed_filename )
		);

		$image_path = $upload_dir['path'] . '/' . $hashed_filename;
		$attach_id = wp_insert_attachment( $attachment, $image_path );

		$imagenew = get_post( $attach_id );
		$fullsizepath = get_attached_file( $imagenew->ID );
		require_once( ABSPATH . 'wp-admin/includes/image.php' );
		// Generate and save the attachment metas into the database
		$attach_data = wp_generate_attachment_metadata( $attach_id, $fullsizepath );
		wp_update_attachment_metadata( $attach_id, $attach_data ); 
		return $attach_id;
	}

}
