jQuery(document).ready(function(){
	var app_key = jQuery('#woocommerce_myob_integrations_WC_MYOB_client_id').val();
	var app_secret = jQuery('#woocommerce_myob_integrations_WC_MYOB_client_secret').val();
	var file_name = jQuery('#woocommerce_myob_integrations_WC_MYOB_company_file_id').val();
	if(app_key!='' && app_secret!=''){
		jQuery('#woocommerce_myob_integrations_allow_access').prop('disabled',false);
		jQuery('#woocommerce_myob_integrations_allow_sync').prop('disabled',false);

		jQuery('#woocommerce_myob_integrations_export_product_to_myob').prop('disabled',false); 
	}
		jQuery('#woocommerce_myob_integrations_reload_accounts_list').prop('disabled',false);
	if (file_name != null && file_name != 0) {
		jQuery('#woocommerce_myob_integrations_allow_access').text('Revalidate Access');
	}
	
	jQuery("#woocommerce_myob_integrations_allow_sync").click( function() {

		var $this = jQuery(this);

		$this.text('Loading... (60 seconds+)');
		$this.prop('disabled', true);

		alert('Inventory quantities will be syncronised from MYOB to WooCommerce in the background once you press OK.   This can take a few minutes to complete.');
		jQuery.ajax({
			type : "post",
			dataType : "json",
			url : ajaxurl,
			data : { action: "MYOB_sync_product_ajax" },
			success: function(response) {
				console.log(response);
				location.reload();
			}
		});
	});


	jQuery("#woocommerce_myob_integrations_reload_accounts_list").click( function() {
		var $this = jQuery(this);

		$this.text('Loading... (20 seconds)');
		$this.prop('disabled', true);

		jQuery.ajax({
			type : "post",
			dataType : "json",
			url : ajaxurl,
			data : { action: "MYOB_reload_accounts_list_ajax" },
			success: function(response) {
				console.log(response);
				location.reload();
			}
		});
	});


	jQuery('#woocommerce_myob_integrations_export_product_to_myob').click( function() {
		var $this = jQuery(this);

		$this.text('Loading...');
		$this.prop('disabled', true);

		jQuery.ajax({
			type : "post",
			dataType : "json",
			url : ajaxurl,
			data : { action: "MYOB_import_product_to_myob" },
			success: function(response) {
				$this.prop('disabled', false);
				console.log(response);
				location.reload();
			}
		});
		console.log($this);
	}); 



	jQuery("#woocommerce_myob_integrations_WC_MYOB_company_file_id").change( function() {
		alert('If you change company file, you may need to reload the accounts list.  To do this, click the Save button, then when the page reloads, click the Reload Accounts List button.');
		jQuery('#woocommerce_myob_integrations_reload_accounts_list').prop('disabled',true);
	});

	jQuery("#woocommerce_myob_integrations_WC_MYOB_invoice_id_prefix").prop('required', true);
	jQuery("#woocommerce_myob_integrations_WC_MYOB_company_file_username").prop('required', true); 
});
