<?php
	$api_client_id_static = '545dj2wk4r8gde2xs39mg366';

	$wp_path = preg_replace('/wp-content(?!.*wp-content).*/', '', __DIR__);
 
	include($wp_path . 'wp-load.php');

	require_once('includes/opmc/class-opmc-logger.php');
	require_once('includes/class-opmc-myob-connector.php');

	Opmc_Logger::debug('Callback from MYOB');


if ( ( isset( $_REQUEST['code'] ) && !empty( $_REQUEST['code'] ) )
	&& ( isset( $_REQUEST['api_client_id'] ) && !empty( $_REQUEST['api_client_id'] ) )
	&& ( isset( $_REQUEST['api_secret'] ) && !empty( $_REQUEST['api_secret'] ) )
	&& ( isset( $_REQUEST['api_redirect_uri'] ) && !empty($_REQUEST['api_redirect_uri'] ) ) ) {
	
	$code = sanitize_textarea_field($_REQUEST['code']);
	$api_client_id = sanitize_textarea_field($_REQUEST['api_client_id']);
	$api_secret = sanitize_textarea_field($_REQUEST['api_secret']);
	$api_redirect_uri = sanitize_textarea_field($_REQUEST['api_redirect_uri']);

	?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title>OPMC MYOB Validation.</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<?php
	function myob_validation_scripts() {
		wp_enqueue_style( 'bootstrapcdn452', 'https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css', array(), '4.5.2');
		wp_enqueue_script( 'ajaxgoogleapis351', 'https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js', array( 'jquery' ), '3.5.1', true );
		wp_enqueue_script( 'cdnjscloudflare1160', 'https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js', array( 'jquery' ), '1.16.0', true );
		wp_enqueue_script( 'bootstrapcdn452', 'https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js', array( 'jquery' ), '4.5.2', true );
	}
	add_action( 'wp_enqueue_scripts', 'myob_validation_scripts' );
	wp_head();
	?>
</head>
<body>
<div class="container" style="margin-top:50px">
	<div class="row">
		<div class="col">
			<?php echo '<img src="' . esc_url( plugins_url( 'assets/images/opmc_logo.png', __FILE__ ) ) . '" class="img-fluid mx-auto d-block" alt="OPMC"> '; ?>
		</div>
		<div class="col">
			<?php echo '<img src="' . esc_url( plugins_url( 'assets/images/myob_logo.png', __FILE__ ) ) . '" class="img-fluid mx-auto d-block" alt="MYOB"> '; ?>
		</div>
	</div>
	<?php

	if ( $api_client_id != $api_client_id_static ) {
		?>
		<div class="alert alert-danger text-center" style="margin-top:30px">
			<div class="d-inline-block"><strong>Error E01:</strong> ID Wrong!</div>
		</div>
		<div class="row" style="margin-top:30px">
		<div class="col">
			<a href="<?php echo esc_url(@get_admin_url(null, 'admin.php?page=wc-settings&tab=integration&section=myob_integrations')); ?>" class="btn btn-primary btn-lg mx-auto d-block" role="button">Return to plugin Page</a>
		</div>
		</div>
		</div>
		</body>
		</html>
		<?php
		exit;
	}

	update_option( 'WC_MYOB_code', $code );
	update_option( 'WC_MYOB_client_id', $api_client_id );
	update_option( 'WC_MYOB_secret', $api_secret );
	update_option( 'WC_MYOB_api_unauthorized_count', 0 );
	   
	if ( get_option( 'WC_MYOB_code' ) ) {			
		// build up the params for generating token 
		$params = array(
			'client_id'				=>	$api_client_id,
			'client_secret'			=>	$api_secret,
			'grant_type'			=>	'authorization_code',
			'code'					=>	urldecode($code),
			'redirect_uri'			=>  $api_redirect_uri,
			'scope'					=> 'CompanyFile'
		); 

		$query = 'client_id=' . $params['client_id'] . '&redirect_uri=' . urlencode( $params['redirect_uri'] ) .
				'&client_secret=' . $params['client_secret'] .
				'&grant_type=authorization_code' .
				'&code=' . urlencode($params['code']) .
				'&scope=CompanyFile';


		$params = http_build_query( $params );

		Opmc_Logger::debug( $query );	
		Opmc_Logger::debug( 'Getting token' );	
				
		// generate token post through api
		$response  = wp_remote_post( 'https://secure.myob.com/oauth2/v1/authorize', array(
			'body' => $query                
		)); 

		Opmc_Logger::debug( 'AUTH RESPONSE' );
		Opmc_Logger::debug( $response );

		if ( '200' == $response['response']['code'] ) {			

			$tokenData = json_decode( $response['body'] );		
			Opmc_Logger::debug( 'TOKEN DATA FOLLOWS' );
			Opmc_Logger::debug( $tokenData );

			// update token related data in option table
			update_option( 'MYOB_access_token', $tokenData->access_token );
			update_option( 'MYOB_access_refresh_token', $tokenData->refresh_token );
			Opmc_Logger::debug( 'REFRESH TOKEN IS' );
			Opmc_Logger::debug( $tokenData->refresh_token );
			$tok = get_option( 'MYOB_access_refresh_token' );
			Opmc_logger::debug( $tok );


			update_option( 'MYOB_access_token_type', $tokenData->token_type );
			update_option( 'MYOB_access_token_scope', $tokenData->scope );
				
			// TODO use the library
			$res = get_company_file( $tokenData->access_token, $api_client_id );

			$current_options = get_option( 'woocommerce_MYOB_integrations_settings', array() );	

			if ( '' != $res ) {

				update_option( 'WC_MYOB_company_file_id', $res );

				$desired_options = array( 'WC_MYOB_company_file_id' => $res );
				$merged_options = array_merge( $current_options, $desired_options );
			
				update_option( 'woocommerce_MYOB_integrations_settings', $merged_options );

				$conn = new Opmc_Myob_Connector();

				update_option( 'WC_MYOB_company_file_list', $conn->get_company_file() );
				update_option( 'WC_MYOB_refresh_token_timestamp', time());
				
			} 
			?>
			<div class="alert alert-success text-center" style="margin-top:30px">
				<div class="d-inline-block"><strong>Success!</strong> Authentication successful.</div>
			</div>
			<?php
		} else {
			?>
				<div class="alert alert-danger text-center" style="margin-top:30px">
					<div class="d-inline-block"><strong>Error E100:</strong> Invalid URL for MYOB authorisation.</div>
				</div>
				<?php
		}			
	} 
} else {
	?>
		<div class="alert alert-danger text-center" style="margin-top:30px">
			<div class="d-inline-block"><strong>Error E100:</strong> Invalid URL for MYOB authorisation.</div>
		</div>
		<?php
}

function get_company_file( $access_token, $api_client_id ) {

	Opmc_Logger::debug('Getting company file');

	$headers = array(
			'Authorization'           => 'bearer ' . $access_token,
			'x-myobapi-key'           => $api_client_id,   
			'Accept-Encoding'         => 'gzip,deflate',
			'x-myobapi-version'       => 'v2',
			'scope'                   => 'CompanyFile',
			'x-myobapi-cftoken'		  => base64_encode('Administrator:'),
		);
		
	Opmc_Logger::debug($headers);

	$res = wp_remote_get( 'https://ar1.api.myob.com/accountright/' , array(
		'headers' =>  $headers,        
	)); 
	$res_body =  json_decode($res['body']);
	Opmc_Logger::debug( '==== Company File results ====' );
	Opmc_Logger::debug($res_body);
		$fileNames = array();
		$fileUriID = array();
	foreach ($res_body as $filesId) {
		if (property_exists($filesId, 'Name') && property_exists($filesId, 'Id')) {
				$fileNames[] = $filesId->Name; 
				$fileUriID[] = $filesId->Id;
		}
	}
	return $fileUriID[0];
}
?>
	<div class="row" style="margin-top:30px">
		<div class="col">
			<a href="<?php echo esc_url(@get_admin_url(null, 'admin.php?page=wc-settings&tab=integration&section=myob_integrations')); ?>" class="btn btn-primary btn-lg mx-auto d-block" role="button">Return to plugin Page</a>
		</div>
	</div>
</div>
</body>
</html>
